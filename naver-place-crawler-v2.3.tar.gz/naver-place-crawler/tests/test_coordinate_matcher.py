"""coordinate_matcher 종합 검증

실제 CSV 데이터 + Phase 1 APOLLO 좌표로 3-Tier 매칭 시뮬레이션
"""
import sys, types, csv, math
from pathlib import Path

# loguru 폴백
if "loguru" not in sys.modules:
    m = types.ModuleType("loguru")
    class _L:
        def debug(self, *a, **k): pass
        def info(self, *a, **k): pass
        def warning(self, msg, *a, **k): print(f"  ⚠ {msg}")
    m.logger = _L()
    sys.modules["loguru"] = m

sys.path.insert(0, str(Path(__file__).parent.parent))
from core.coordinate_matcher import (
    haversine_distance, naver_coord_to_latlng,
    match_by_coordinates, match_best_candidate,
    name_similarity, address_similarity,
    normalize_name, build_search_queries, extract_region,
)

PASS = 0
FAIL = 0

def check(label, condition, detail=""):
    global PASS, FAIL
    if condition:
        PASS += 1
        print(f"  ✅ {label}" + (f" → {detail}" if detail else ""))
    else:
        FAIL += 1
        print(f"  ❌ {label}" + (f" → {detail}" if detail else ""))


# ═══════════════════════════════════════════════════
print("=" * 60)
print("  TEST 1: haversine_distance 정확도")
print("=" * 60)

# 서울역 → 서울시청 (약 1.3km)
d = haversine_distance(37.5547, 126.9707, 37.5662, 126.9780)
check("서울역↔시청", 1200 < d < 1500, f"{d:.0f}m")

# 동일 좌표
d0 = haversine_distance(37.5, 127.0, 37.5, 127.0)
check("동일좌표=0m", d0 < 0.1, f"{d0:.4f}m")

# CSV→APOLLO 오차 (고은미인의원: Phase1 실측)
csv_lat, csv_lng = naver_coord_to_latlng(1269562840, 374796070)
apollo_lat, apollo_lng = 37.4796129, 126.9562837
d_err = haversine_distance(csv_lat, csv_lng, apollo_lat, apollo_lng)
check("CSV↔APOLLO 오차 <2m", d_err < 2, f"{d_err:.2f}m")


# ═══════════════════════════════════════════════════
print(f"\n{'=' * 60}")
print("  TEST 2: naver_coord_to_latlng 변환")
print("=" * 60)

lat, lng = naver_coord_to_latlng(1269562840, 374796070)
check("위도 37.48", 37.47 < lat < 37.49, f"lat={lat:.7f}")
check("경도 126.96", 126.95 < lng < 126.96, f"lng={lng:.7f}")

# 부산 좌표
lat2, lng2 = naver_coord_to_latlng(1290724100, 351729200)
check("부산 위도 35.17", 35.1 < lat2 < 35.2, f"lat={lat2:.7f}")


# ═══════════════════════════════════════════════════
print(f"\n{'=' * 60}")
print("  TEST 3: name_similarity 병원명 유사도")
print("=" * 60)

check("정확 일치", name_similarity("아름다운피부과의원", "아름다운피부과의원") == 1.0)
check("공백 무시", name_similarity("아름다운 피부과의원", "아름다운피부과의원") == 1.0)
check("포함 관계", name_similarity("오라클피부과", "오라클피부과의원") == 0.8)
check("완전 다른 이름 <0.5",
      name_similarity("고은미인의원", "서울피부과의원") < 0.5,
      f"{name_similarity('고은미인의원', '서울피부과의원'):.2f}")
check("normalize 괄호", normalize_name("아름다운(피부과)의원") == "아름다운피부과의원")


# ═══════════════════════════════════════════════════
print(f"\n{'=' * 60}")
print("  TEST 4: address_similarity 주소 유사도")
print("=" * 60)

a1 = "서울특별시 관악구 남부순환로 1860"
a2 = "서울특별시 관악구 남부순환로 1860 고운빌딩 3층"
sim = address_similarity(a1, a2)
check("동일 주소 (상세 차이)", sim >= 0.7, f"{sim:.2f}")

a3 = "경기도 수원시 영통구 봉영로 1590"
a4 = "서울특별시 강남구 논현로 521"
sim2 = address_similarity(a3, a4)
check("완전 다른 주소 <0.3", sim2 < 0.3, f"{sim2:.2f}")

a5 = "서울특별시 관악구 봉천로 200"
a6 = "서울특별시 동작구 사당로 300"
sim3 = address_similarity(a5, a6)
check("같은 시/다른 구", 0.2 < sim3 < 0.5, f"{sim3:.2f}")

# 시도 정규화
a7 = "경기도 수원시 영통구 봉영로 1590"
a8 = "경기 수원시 영통구 봉영로 1590"
sim4 = address_similarity(a7, a8)
check("경기도↔경기 정규화", sim4 >= 0.8, f"{sim4:.2f}")


# ═══════════════════════════════════════════════════
print(f"\n{'=' * 60}")
print("  TEST 5: match_by_coordinates (좌표만 매칭)")
print("=" * 60)

# 시나리오: 수원 영통 아름다운피부과 CSV → 후보 3개
csv_mapx = 1270731972  # 경도×10^7 (수원 영통)
csv_mapy = 372528344   # 위도×10^7

candidates = [
    {"place_id": "13228676", "lat": 37.2528344, "lng": 127.0731972, "name": "아름다운피부과의원"},  # 수원 영통 (정답)
    {"place_id": "11863699", "lat": 37.5021600, "lng": 127.0113400, "name": "아름다운피부과의원"},  # 서초
    {"place_id": "99999999", "lat": 35.1791700, "lng": 128.0913500, "name": "아름다운피부과의원"},  # 진주
]

result = match_by_coordinates(csv_mapx, csv_mapy, candidates)
check("정확한 ID 매칭", result and result["place_id"] == "13228676",
      f"id={result['place_id'] if result else 'None'}")
check("거리 <10m", result and result["match_distance_m"] < 10,
      f"{result['match_distance_m'] if result else '?'}m")
check("신뢰도 1.0", result and result["match_confidence"] == 1.0)


# ═══════════════════════════════════════════════════
print(f"\n{'=' * 60}")
print("  TEST 6: match_best_candidate (종합 점수 매칭)")
print("=" * 60)

csv_row = {
    "naver_name": "아름다운피부과의원",
    "naver_address": "경기도 수원시 영통구 봉영로 1590 밀레니엄플라자 304호",
    "naver_mapx": "1270731972",
    "naver_mapy": "372528344",
}

# 후보: 좌표 있는 것 + 없는 것 혼합
candidates2 = [
    {"place_id": "13228676", "lat": 37.2528344, "lng": 127.0731972,
     "name": "아름다운피부과의원", "address": "경기 수원시 영통구 봉영로 1590 밀레니엄플라자 304호"},
    {"place_id": "11863699", "lat": 37.5021600, "lng": 127.0113400,
     "name": "아름다운피부과의원", "address": "서울특별시 서초구 서초중앙로 229"},
    {"place_id": "20373503", "lat": None, "lng": None,
     "name": "", "address": ""},  # 좌표 없는 후보
]

result2 = match_best_candidate(csv_row, candidates2)
check("종합매칭 정답", result2 and result2["place_id"] == "13228676",
      f"id={result2['place_id'] if result2 else 'None'}")
check("종합점수 높음", result2 and result2.get("match_score", 0) > 70,
      f"score={result2.get('match_score', 0) if result2 else '?'}")
check("2위와 격차 >10", result2 and result2.get("match_gap", 0) > 10,
      f"gap={result2.get('match_gap', 0) if result2 else '?'}")


# ═══════════════════════════════════════════════════
print(f"\n{'=' * 60}")
print("  TEST 7: 엣지케이스 — 좌표 없는 후보만")
print("=" * 60)

no_coord_candidates = [
    {"place_id": "AAA", "lat": None, "lng": None, "name": "고은미인의원", "address": "서울 관악구"},
    {"place_id": "BBB", "lat": None, "lng": None, "name": "고은미인의원", "address": "서울 강남구"},
]
csv_row2 = {
    "naver_name": "고은미인의원",
    "naver_address": "서울특별시 관악구 남부순환로 1860",
    "naver_mapx": "1269562840",
    "naver_mapy": "374796070",
}

result3 = match_best_candidate(csv_row2, no_coord_candidates)
# 좌표 0점이지만 이름(30점)+주소(~12점)로 매칭 가능해야 함
if result3:
    check("좌표없이 이름+주소로 매칭", result3["place_id"] == "AAA",
          f"id={result3['place_id']}, score={result3.get('match_score',0):.1f}")
else:
    check("좌표없이 이름+주소로 매칭", False, "result=None")


# ═══════════════════════════════════════════════════
print(f"\n{'=' * 60}")
print("  TEST 8: 엣지케이스 — 모든 후보 임계값 초과")
print("=" * 60)

far_candidates = [
    {"place_id": "FAR1", "lat": 33.0, "lng": 126.0, "name": "다른의원", "address": "제주"},
]
csv_row3 = {
    "naver_name": "고은미인의원",
    "naver_address": "서울특별시 관악구 남부순환로 1860",
    "naver_mapx": "1269562840",
    "naver_mapy": "374796070",
}
result4 = match_best_candidate(csv_row3, far_candidates)
check("매칭 실패 → None", result4 is None)


# ═══════════════════════════════════════════════════
print(f"\n{'=' * 60}")
print("  TEST 9: build_search_queries 쿼리 생성")
print("=" * 60)

csv_row4 = {
    "naver_name": "아름다운피부과의원",
    "naver_address": "경기도 수원시 영통구 봉영로 1590",
}
queries = build_search_queries(csv_row4)
check("Tier 1 기본쿼리", queries[0]["query"] == "아름다운피부과의원 병원")
check("Tier 2 구군쿼리", any("수원시" in q["query"] for q in queries))
check("Tier 2 시도쿼리", any("경기" in q["query"] for q in queries))

csv_row5 = {"naver_name": "고은미인의원", "naver_address": "서울특별시 관악구 남부순환로 1860"}
queries2 = build_search_queries(csv_row5)
check("서울 정규화", any("서울" in q["query"] for q in queries2))


# ═══════════════════════════════════════════════════
print(f"\n{'=' * 60}")
print("  TEST 10: 실전 시뮬레이션 — CSV 27개 아름다운피부과")
print("=" * 60)

# 실제 CSV에서 아름다운피부과의원 27개 로드
csv_path = Path(__file__).parent.parent / "input" / "skin_clinics.csv"
if csv_path.exists():
    with open(csv_path, encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        arum_rows = [r for r in reader if r["naver_name"] == "아름다운피부과의원"]

    # 각 행마다 가상 후보 5개 생성 (정답 1 + 오답 4)
    correct = 0
    for row in arum_rows:
        target_lat, target_lng = naver_coord_to_latlng(
            float(row["naver_mapx"]), float(row["naver_mapy"]))
        addr = row["naver_address"]

        # 정답 후보 (CSV 좌표 ± 미세 오차)
        correct_candidate = {
            "place_id": "CORRECT",
            "lat": target_lat + 0.00001,  # ~1m 오차
            "lng": target_lng - 0.00001,
            "name": "아름다운피부과의원",
            "address": addr,
        }

        # 오답 후보 (다른 아름다운피부과 좌표)
        wrong = []
        for other in arum_rows:
            if other is row:
                continue
            o_lat, o_lng = naver_coord_to_latlng(
                float(other["naver_mapx"]), float(other["naver_mapy"]))
            wrong.append({
                "place_id": f"WRONG_{other['naver_address'][:10]}",
                "lat": o_lat, "lng": o_lng,
                "name": "아름다운피부과의원",
                "address": other["naver_address"],
            })

        all_candidates = [correct_candidate] + wrong[:4]

        result = match_best_candidate(row, all_candidates)
        if result and result["place_id"] == "CORRECT":
            correct += 1

    check(f"27개 중 {correct}개 정확 매칭",
          correct == len(arum_rows),
          f"{correct}/{len(arum_rows)} ({correct/len(arum_rows)*100:.0f}%)")
else:
    print("  ⚠ CSV 파일 없음, 스킵")


# ═══════════════════════════════════════════════════
print(f"\n{'=' * 60}")
print(f"  종합: ✅ {PASS} 통과 / ❌ {FAIL} 실패")
print(f"{'=' * 60}")
sys.exit(0 if FAIL == 0 else 1)
