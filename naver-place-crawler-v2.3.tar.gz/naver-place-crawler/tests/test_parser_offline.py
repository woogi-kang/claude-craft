"""오프라인 파서 검증 스크립트

업로드된 실제 HTML 파일로 v2.2 파서의 모든 필드 추출을 검증합니다.
사용법: python tests/test_parser_offline.py --html-dir results/html_dump
"""

import sys
import json
import types
from pathlib import Path

# loguru 폴백
if "loguru" not in sys.modules:
    m = types.ModuleType("loguru")
    class _L:
        def debug(self, *a, **k): pass
        def info(self, *a, **k): pass
        def warning(self, msg, *a, **k): print(f"  ⚠ {msg}")
    m.logger = _L()
    sys.modules["loguru"] = m

# 프로젝트 루트를 path에 추가
sys.path.insert(0, str(Path(__file__).parent.parent))
from core.naver_data_parser import NaverDataParser


def test_home(html_path: Path, place_id: str):
    """home 페이지 파싱 검증"""
    html = html_path.read_text(encoding="utf-8")
    result = NaverDataParser.parse_home(html, place_id)

    print(f"\n{'─' * 50}")
    print(f"  HOME: {html_path.name} (ID: {place_id})")
    print(f"{'─' * 50}")

    expected_fields = {
        "name": "병원 이름",
        "road_address": "도로명 주소",
        "address": "지번 주소",
        "category": "카테고리",
        "coordinate_x": "경도",
        "coordinate_y": "위도",
        "phone": "전화번호",
        "visitor_reviews_total": "리뷰 수",
        "visitor_reviews_score": "리뷰 점수",
        "operating_hours": "영업시간",
        "lunch_break": "점심시간",
        "closed_days": "휴무일",
        "amenities": "편의시설",
        "homepage_url": "홈페이지",
        "blog_url": "블로그",
    }

    ok = 0
    fail = 0
    for field, label in expected_fields.items():
        val = result.get(field)
        if val is not None:
            ok += 1
            display = str(val)[:70]
            print(f"  ✅ {label:12s} │ {display}")
        else:
            fail += 1
            print(f"  ❌ {label:12s} │ None")

    return ok, fail, result


def test_information(html_path: Path):
    """information 페이지 파싱 검증"""
    html = html_path.read_text(encoding="utf-8")
    result = NaverDataParser.parse_information(html)

    print(f"\n{'─' * 50}")
    print(f"  INFORMATION: {html_path.name}")
    print(f"{'─' * 50}")

    expected_fields = {
        "description": "소개",
        "parking_available": "주차 가능",
        "parking_detail": "주차 상세",
        "youtube_url": "유튜브",
        "instagram_url": "인스타그램",
        "blog_url": "블로그",
        "booking_url": "예약",
        "kakao_url": "카카오",
        "homepage_url": "홈페이지",
    }

    ok = 0
    fail = 0
    for field, label in expected_fields.items():
        val = result.get(field)
        if val is not None:
            ok += 1
            display = str(val)[:70]
            print(f"  ✅ {label:12s} │ {display}")
        else:
            fail += 1
            print(f"  ⬚  {label:12s} │ None (이 병원에 없을 수 있음)")

    return ok, fail, result


def test_photo(html_path: Path):
    """photo 페이지 파싱 검증"""
    html = html_path.read_text(encoding="utf-8")
    result = NaverDataParser.parse_photos(html)

    print(f"\n{'─' * 50}")
    print(f"  PHOTO: {html_path.name}")
    print(f"{'─' * 50}")

    count = result["total_count"]
    if count > 0:
        print(f"  ✅ 사진 수: {count}장 (has_more={result['has_more']})")
        for i, url in enumerate(result["photos"][:3]):
            print(f"     [{i}] {url[:80]}...")
        return count, 0, result
    else:
        print(f"  ❌ 사진 없음")
        return 0, 1, result


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--html-dir", default="results/html_dump",
                        help="HTML 덤프 디렉토리")
    args = parser.parse_args()

    html_dir = Path(args.html_dir)
    if not html_dir.exists():
        print(f"❌ HTML 디렉토리 없음: {html_dir}")
        print(f"   Phase 1을 먼저 실행하거나, --html-dir로 경로를 지정하세요.")
        sys.exit(1)

    print("=" * 60)
    print("  네이버 플레이스 파서 v2.2 오프라인 검증")
    print("=" * 60)

    total_ok = 0
    total_fail = 0

    # home 파일들
    for f in sorted(html_dir.glob("home_*.html")):
        place_id = f.stem.split("_")[1]
        ok, fail, _ = test_home(f, place_id)
        total_ok += ok
        total_fail += fail

    # information 파일들
    for f in sorted(html_dir.glob("information_*.html")):
        ok, fail, _ = test_information(f)
        total_ok += ok
        total_fail += fail

    # photo 파일들
    for f in sorted(html_dir.glob("photo_*.html")):
        ok, fail, _ = test_photo(f)
        total_ok += ok
        total_fail += fail

    print(f"\n{'=' * 60}")
    print(f"  종합 결과: ✅ {total_ok} 성공 / ❌ {total_fail} 실패")
    rate = total_ok / (total_ok + total_fail) * 100 if (total_ok + total_fail) > 0 else 0
    print(f"  추출률: {rate:.1f}%")
    print(f"{'=' * 60}")


if __name__ == "__main__":
    main()
