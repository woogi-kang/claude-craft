"""
core/retry_handler.py — 지수 백오프 재시도 핸들러
"""
from __future__ import annotations
import asyncio, functools
from typing import Any, Callable, TypeVar
from core.logger import logger
from core.config import MAX_RETRIES, RETRY_BACKOFF_BASE
from core.rate_limiter import is_blocked

T = TypeVar("T")


class RetryExhausted(Exception):
    """최대 재시도 횟수 초과"""
    pass


async def retry_async(
    func: Callable,
    *args,
    max_retries: int = MAX_RETRIES,
    backoff_base: float = RETRY_BACKOFF_BASE,
    **kwargs,
) -> Any:
    """비동기 함수 재시도 래퍼

    지수 백오프: base * 3^attempt (5s → 15s → 45s)
    """
    last_error = None
    for attempt in range(max_retries + 1):
        try:
            return await func(*args, **kwargs)
        except Exception as e:
            last_error = e
            if attempt < max_retries:
                delay = backoff_base * (3 ** attempt)
                logger.warning(
                    f"재시도 {attempt+1}/{max_retries}: {type(e).__name__}: {e}. "
                    f"{delay:.0f}초 후 재시도..."
                )
                await asyncio.sleep(delay)
            else:
                logger.error(f"최대 재시도 초과: {type(e).__name__}: {e}")
    raise RetryExhausted(f"{max_retries}회 재시도 후 실패: {last_error}")


def with_retry(max_retries: int = MAX_RETRIES, backoff_base: float = RETRY_BACKOFF_BASE):
    """데코레이터: 비동기 함수에 자동 재시도 적용"""
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            return await retry_async(func, *args, max_retries=max_retries,
                                      backoff_base=backoff_base, **kwargs)
        return wrapper
    return decorator
