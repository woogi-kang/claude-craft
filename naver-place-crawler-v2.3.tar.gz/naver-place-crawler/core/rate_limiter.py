"""core/rate_limiter.py — 요청 속도 제어 + 차단 감지

딜레이 전략:
  - 같은 병원 내 페이지 이동: 3~6초 (10% 확률 +2~5초 jitter)
  - 병원 간 전환: 4~8초 (10% 확률 +3~8초 jitter)
  - 배치 쿨다운: 30건마다 2~4분 휴식
  - 지역 전환: 5분 휴식
  - 차단 감지 시: 60/120/300/600초 점진적 대기

예상 속도 (4,255병원):
  - 병원당: 검색(1) + home(1) + info(1) + photo(1) = 4요청
  - 요청간 ~4.5초 + 병원간 ~6초 = 병원당 ~24초
  - 30건 배치 = ~12분 + 쿨다운 3분 = ~15분/배치
  - 142배치 x 15분 = ~35.5시간 (안전 마진 포함)
  - 실제: 약 12~18시간 (차단 없을 경우)
"""
from __future__ import annotations
import asyncio
import random

from core.logger import logger
from core.config import (
    REQUEST_DELAY_MIN, REQUEST_DELAY_MAX,
    PAGE_READ_DELAY_MIN, PAGE_READ_DELAY_MAX,
    BATCH_SIZE, BATCH_COOLDOWN_MIN, BATCH_COOLDOWN_MAX,
    REGION_COOLDOWN, BLOCK_DETECT_WAIT_TIMES,
)


class RateLimiter:
    def __init__(self) -> None:
        self._request_count = 0
        self._batch_count = 0
        self._hospital_count = 0

    async def wait_between_requests(self) -> None:
        """같은 병원 내 페이지 이동 딜레이 (home->info->photo)"""
        delay = random.uniform(REQUEST_DELAY_MIN, REQUEST_DELAY_MAX)
        # 10% 확률로 추가 jitter (인간 행동 시뮬레이션)
        if random.random() < 0.1:
            delay += random.uniform(2.0, 5.0)
        await asyncio.sleep(delay)
        self._request_count += 1

    async def wait_page_navigation(self) -> None:
        """병원 간 전환 딜레이 (더 긴 대기)"""
        delay = random.uniform(PAGE_READ_DELAY_MIN, PAGE_READ_DELAY_MAX)
        if random.random() < 0.1:
            delay += random.uniform(3.0, 8.0)
        await asyncio.sleep(delay)

    async def page_delay(self) -> None:
        """페이지 간 딜레이 (간편 메서드) - 같은 병원 내"""
        await self.wait_between_requests()

    async def hospital_done(self) -> None:
        """한 병원 크롤링 완료 후 호출 - 배치 쿨다운 체크 포함"""
        self._hospital_count += 1
        self._batch_count += 1

        if self._batch_count >= BATCH_SIZE:
            delay = random.uniform(BATCH_COOLDOWN_MIN, BATCH_COOLDOWN_MAX)
            logger.info(
                f"배치 쿨다운: {delay:.0f}초 대기 "
                f"({self._hospital_count}번째 병원, 배치 {self._batch_count}건)"
            )
            self._batch_count = 0
            await asyncio.sleep(delay)
        else:
            # 병원 간 기본 전환 딜레이
            await self.wait_page_navigation()

    async def wait_batch_cooldown(self) -> None:
        """수동 배치 쿨다운 (hospital_done 외 추가 호출용)"""
        self._batch_count += 1
        if self._batch_count % BATCH_SIZE == 0:
            delay = random.uniform(BATCH_COOLDOWN_MIN, BATCH_COOLDOWN_MAX)
            logger.info(f"배치 쿨다운: {delay:.0f}초 ({self._batch_count}건 처리 후)")
            await asyncio.sleep(delay)

    async def wait_region_change(self) -> None:
        """지역(시/도) 전환 시 긴 쿨다운"""
        logger.info(f"지역 전환 쿨다운: {REGION_COOLDOWN}초")
        await asyncio.sleep(REGION_COOLDOWN)

    async def wait_blocked(self, attempt: int) -> None:
        """차단 감지 시 점진적 대기"""
        idx = min(attempt, len(BLOCK_DETECT_WAIT_TIMES) - 1)
        delay = BLOCK_DETECT_WAIT_TIMES[idx]
        logger.warning(f"차단 감지! {delay}초 대기 (시도 #{attempt + 1})")
        await asyncio.sleep(delay)

    @property
    def stats(self) -> dict:
        return {
            "total_requests": self._request_count,
            "hospitals_done": self._hospital_count,
            "current_batch": self._batch_count,
        }


def is_blocked(status_code: int, html: str = "") -> bool:
    """응답에서 차단 여부 감지"""
    if status_code in (403, 429):
        return True
    block_keywords = ["비정상적인 접근", "자동화된 요청", "captcha", "보안문자"]
    return any(kw in html.lower() for kw in block_keywords)


async def page_delay():
    """페이지 간 딜레이 (모듈 수준 간편 함수)"""
    delay = random.uniform(REQUEST_DELAY_MIN, REQUEST_DELAY_MAX)
    if random.random() < 0.1:
        delay += random.uniform(2.0, 5.0)
    await asyncio.sleep(delay)
