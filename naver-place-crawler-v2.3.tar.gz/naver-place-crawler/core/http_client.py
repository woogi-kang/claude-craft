"""네이버 크롤링 전용 HTTP 클라이언트 (Headless 브라우저 사용 금지)"""
import asyncio
import random
from typing import Optional
from urllib.parse import urlencode, quote, urlparse, urlunparse

import httpx
from core.logger import logger

from core.config import (
    HTTP_TIMEOUT, MAX_REQUESTS_PER_SESSION, MOBILE_USER_AGENTS,
    SESSION_ROTATE_COOLDOWN,
)


class BlockDetectedError(Exception):
    """네이버 차단 감지"""
    pass


class NaverHTTPClient:
    def __init__(self):
        self._client: Optional[httpx.AsyncClient] = None
        self._request_count: int = 0
        self._current_ua: str = ""

    async def start(self):
        """세션 초기화"""
        await self._create_session()

    async def close(self):
        if self._client:
            await self._client.aclose()
            self._client = None

    async def force_rotate(self):
        """강제 세션 교체"""
        logger.info(f"강제 세션 교체, {SESSION_ROTATE_COOLDOWN}초 대기...")
        await asyncio.sleep(SESSION_ROTATE_COOLDOWN)
        await self._create_session()

    async def _create_session(self):
        if self._client:
            await self._client.aclose()
        self._current_ua = random.choice(MOBILE_USER_AGENTS)
        self._client = httpx.AsyncClient(
            headers={
                "User-Agent": self._current_ua,
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7",
                "Accept-Encoding": "gzip, deflate",  # br(brotli) 제외: brotli 미설치 시 깨짐 방지
                "Connection": "keep-alive",
                "Sec-Fetch-Dest": "document",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Site": "none",
                "Sec-Fetch-User": "?1",
                "Upgrade-Insecure-Requests": "1",
            },
            follow_redirects=True,
            timeout=httpx.Timeout(HTTP_TIMEOUT),
            http2=True,
        )
        self._request_count = 0
        logger.debug(f"새 HTTP 세션 | UA: {self._current_ua[:50]}...")

    async def _maybe_rotate(self):
        if self._request_count >= MAX_REQUESTS_PER_SESSION:
            logger.info(f"세션 한도 도달 ({self._request_count}건), 교체...")
            await self.force_rotate()

    def _check_blocked(self, response: httpx.Response) -> None:
        if response.status_code in (403, 429):
            raise BlockDetectedError(f"HTTP {response.status_code}: {response.url}")
        text = response.text[:2000] if response.text else ""
        for kw in ["비정상적인 접근", "자동화된 요청", "captcha", "CAPTCHA"]:
            if kw in text:
                raise BlockDetectedError(f"차단 감지 '{kw}': {response.url}")

    @staticmethod
    def _encode_url(url: str) -> str:
        """비ASCII 문자가 포함된 URL을 퍼센트 인코딩"""
        parsed = urlparse(url)
        # path와 query에 한글이 있을 수 있음
        encoded = urlunparse((
            parsed.scheme,
            parsed.netloc,
            quote(parsed.path, safe="/:@!$&'()*+,;=-._~"),
            parsed.params,
            quote(parsed.query, safe="/:@!$&'()*+,;=-._~=?"),
            parsed.fragment,
        ))
        return encoded

    async def get(self, url: str, params: dict = None, referer: str = None,
                  check_block: bool = True) -> httpx.Response:
        await self._maybe_rotate()
        headers = {}
        if referer:
            headers["Referer"] = self._encode_url(referer)
            headers["Sec-Fetch-Site"] = "same-origin"
        if params:
            url = f"{url}?{urlencode(params, encoding='utf-8')}"
        response = await self._client.get(url, headers=headers)
        self._request_count += 1
        logger.debug(f"GET {response.status_code} | {len(response.text):,}B | {url[:80]}")
        if check_block:
            self._check_blocked(response)
        return response

    async def get_bytes(self, url: str, referer: str = None) -> httpx.Response:
        await self._maybe_rotate()
        headers = {"Referer": self._encode_url(referer)} if referer else {}
        response = await self._client.get(url, headers=headers)
        self._request_count += 1
        return response

    @property
    def request_count(self) -> int:
        return self._request_count
