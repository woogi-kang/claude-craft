"""
구조화된 로깅 설정
loguru가 없으면 표준 logging으로 폴백합니다.
"""
import sys

try:
    from loguru import logger as _loguru_logger

    HAS_LOGURU = True

    def setup_logger(log_name: str = "crawl") -> None:
        from core.config import LOGS_DIR, LOG_FORMAT, LOG_ROTATION, LOG_RETENTION
        _loguru_logger.remove()
        _loguru_logger.add(sys.stderr, format=LOG_FORMAT, level="INFO", colorize=True)
        LOGS_DIR.mkdir(parents=True, exist_ok=True)
        _loguru_logger.add(
            LOGS_DIR / f"{log_name}_{{time:YYYY-MM-DD}}.log",
            format=LOG_FORMAT, level="DEBUG",
            rotation=LOG_ROTATION, retention=LOG_RETENTION, encoding="utf-8",
        )
        _loguru_logger.add(
            LOGS_DIR / f"{log_name}_errors_{{time:YYYY-MM-DD}}.log",
            format=LOG_FORMAT, level="ERROR",
            rotation=LOG_ROTATION, retention=LOG_RETENTION, encoding="utf-8",
        )
        _loguru_logger.info("Logger initialized: {}", log_name)

    logger = _loguru_logger

except ImportError:
    import logging

    HAS_LOGURU = False
    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)s | %(levelname)-8s | %(name)s:%(funcName)s:%(lineno)d | %(message)s",
        stream=sys.stderr,
    )

    class _FallbackLogger:
        """loguru 호환 폴백 로거"""
        def __init__(self):
            self._logger = logging.getLogger("crawler")

        def _fmt(self, msg, *args):
            # loguru style {} formatting → str.format
            try:
                return str(msg).format(*args)
            except (IndexError, KeyError):
                return str(msg)

        def debug(self, msg, *args, **kw): self._logger.debug(self._fmt(msg, *args))
        def info(self, msg, *args, **kw): self._logger.info(self._fmt(msg, *args))
        def warning(self, msg, *args, **kw): self._logger.warning(self._fmt(msg, *args))
        def error(self, msg, *args, **kw): self._logger.error(self._fmt(msg, *args))
        def critical(self, msg, *args, **kw): self._logger.critical(self._fmt(msg, *args))

    logger = _FallbackLogger()

    def setup_logger(log_name: str = "crawl") -> None:
        logger.info("Using fallback logger (loguru not installed)")


def get_logger(name: str = "crawler"):
    """named logger 반환 (loguru에서는 bind, 폴백에서는 무시)"""
    if HAS_LOGURU:
        return _loguru_logger.bind(module=name)
    else:
        return logger
