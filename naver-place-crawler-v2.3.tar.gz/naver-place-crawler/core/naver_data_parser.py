"""네이버 플레이스 데이터 파서 v2.2

실제 HTML 분석 결과 기반 (2026-02-06 Phase 1 검증 완료):

데이터 소스:
  - window.__APOLLO_STATE__  → 핵심 구조화 데이터 (JSON)
    └ PlaceDetailBase:{id}   → 이름, 주소, 좌표, 편의시설, 전화, 리뷰
  - window.__PLACE_STATE__   → i18n 번역 리소스만 (사용 안 함)
  - DOM 파싱                 → 영업시간, 휴무일, 소개, 주차, SNS 링크, 사진

검색 페이지:
  - __APOLLO_STATE__ 없음 (CSR)
  - /hospital/{id} 링크 패턴에서 Place ID 추출
"""

import json
import re
from typing import Any, Optional

from bs4 import BeautifulSoup
from core.logger import logger


class NaverDataParser:
    """네이버 플레이스 HTML/JSON 파서 (static methods)"""

    # ──────────────────────────────────────────────
    # 1. JSON 추출
    # ──────────────────────────────────────────────

    @staticmethod
    def extract_apollo_state(html: str) -> Optional[dict]:
        """HTML에서 window.__APOLLO_STATE__ JSON 추출 (중괄호 매칭)"""
        idx = html.find("window.__APOLLO_STATE__")
        if idx < 0:
            return None

        eq = html.find("=", idx)
        start = html.find("{", eq)
        if start < 0:
            return None

        depth = 0
        end = start
        for i in range(start, min(start + 600_000, len(html))):
            if html[i] == "{":
                depth += 1
            elif html[i] == "}":
                depth -= 1
                if depth == 0:
                    end = i + 1
                    break

        try:
            data = json.loads(html[start:end])
            logger.debug(f"__APOLLO_STATE__ 추출 성공 | {len(data)} keys")
            return data
        except json.JSONDecodeError as e:
            logger.warning(f"__APOLLO_STATE__ JSON 파싱 실패: {e}")
            return None

    @staticmethod
    def extract_next_data(html: str) -> Optional[dict]:
        """하위 호환: __APOLLO_STATE__ 우선, __PLACE_STATE__ 폴백"""
        apollo = NaverDataParser.extract_apollo_state(html)
        if apollo:
            return apollo

        for pattern_name, pattern in [
            ("__PLACE_STATE__", r"window\.__PLACE_STATE__\s*=\s*({.+?})\s*;"),
        ]:
            match = re.search(pattern, html, re.DOTALL)
            if match:
                try:
                    data = json.loads(match.group(1))
                    logger.debug(f"{pattern_name} 추출 성공")
                    return data
                except json.JSONDecodeError:
                    continue

        logger.warning("__NEXT_DATA__ 및 인라인 JSON 없음")
        return None

    @staticmethod
    def get_place_detail(apollo: dict, place_id: str = None) -> Optional[dict]:
        """APOLLO_STATE에서 PlaceDetailBase 객체 추출"""
        if not apollo:
            return None
        if place_id:
            key = f"PlaceDetailBase:{place_id}"
            if key in apollo:
                return apollo[key]
        for key in apollo:
            if key.startswith("PlaceDetailBase:"):
                return apollo[key]
        return None

    @staticmethod
    def safe_get(data: dict, path: str, default: Any = None) -> Any:
        """점(.) 구분자 경로로 중첩 딕셔너리 안전 접근"""
        keys = path.split(".")
        current = data
        for key in keys:
            if isinstance(current, dict):
                current = current.get(key)
            elif isinstance(current, list):
                try:
                    current = current[int(key)]
                except (ValueError, IndexError):
                    return default
            else:
                return default
            if current is None:
                return default
        return current

    @staticmethod
    def deep_find(data, target_key: str, max_depth: int = 10):
        """재귀적으로 키를 탐색"""
        if max_depth <= 0:
            return None
        if isinstance(data, dict):
            if target_key in data:
                return data[target_key]
            for v in data.values():
                result = NaverDataParser.deep_find(v, target_key, max_depth - 1)
                if result is not None:
                    return result
        elif isinstance(data, list):
            for item in data:
                result = NaverDataParser.deep_find(item, target_key, max_depth - 1)
                if result is not None:
                    return result
        return None

    # ──────────────────────────────────────────────
    # 2. 검색 결과 파싱
    # ──────────────────────────────────────────────

    @staticmethod
    def parse_search_results(html: str) -> list:
        """검색 결과 HTML에서 Place ID 후보 목록 추출

        검색 페이지는 CSR이므로 __APOLLO_STATE__ 없음.
        /hospital/{id} 링크 패턴에서 ID 추출.
        """
        candidates = []
        seen_ids = set()

        # /hospital/{id} 패턴
        ids = re.findall(r"/hospital/(\d{7,10})", html)
        for pid in ids:
            if pid not in seen_ids:
                seen_ids.add(pid)
                candidates.append({
                    "place_id": pid,
                    "name": "",
                    "address": "",
                    "lat": None,
                    "lng": None,
                })

        # /place/{id} 패턴
        ids2 = re.findall(r"/place/(\d{7,10})", html)
        for pid in ids2:
            if pid not in seen_ids:
                seen_ids.add(pid)
                candidates.append({
                    "place_id": pid,
                    "name": "",
                    "address": "",
                    "lat": None,
                    "lng": None,
                })

        # APOLLO_STATE가 있으면 이름/주소 보충
        apollo = NaverDataParser.extract_apollo_state(html)
        if apollo:
            for cand in candidates:
                detail = NaverDataParser.get_place_detail(apollo, cand["place_id"])
                if detail:
                    cand["name"] = detail.get("name", "")
                    cand["address"] = detail.get("roadAddress", "") or detail.get("address", "")
                    coord = detail.get("coordinate", {})
                    if coord:
                        try:
                            cand["lng"] = float(coord.get("x", 0))
                            cand["lat"] = float(coord.get("y", 0))
                        except (TypeError, ValueError):
                            pass

        logger.debug(f"검색 결과: {len(candidates)}개 후보")
        return candidates

    # ──────────────────────────────────────────────
    # 3. Home 페이지 파싱
    # ──────────────────────────────────────────────

    @staticmethod
    def parse_home(html: str, place_id: str = None) -> dict:
        """home 페이지에서 영업시간 + 편의시설 + 기본정보 추출"""
        result = {
            "operating_hours": None,
            "lunch_break": None,
            "last_order": None,
            "closed_days": None,
            "amenities": None,
            "name": None,
            "road_address": None,
            "address": None,
            "category": None,
            "coordinate_x": None,
            "coordinate_y": None,
            "phone": None,
            "visitor_reviews_total": None,
            "visitor_reviews_score": None,
            "homepage_url": None,
            "blog_url": None,
        }

        # APOLLO_STATE에서 구조화 데이터
        apollo = NaverDataParser.extract_apollo_state(html)
        if apollo:
            detail = NaverDataParser.get_place_detail(apollo, place_id)
            if detail:
                result["name"] = detail.get("name")
                result["road_address"] = detail.get("roadAddress")
                result["address"] = detail.get("address")
                result["category"] = detail.get("category")
                result["phone"] = detail.get("virtualPhone") or detail.get("phone")
                result["visitor_reviews_total"] = detail.get("visitorReviewsTotal")
                result["visitor_reviews_score"] = detail.get("visitorReviewsScore")
                conv = detail.get("conveniences")
                if conv and isinstance(conv, list):
                    result["amenities"] = conv
                coord = detail.get("coordinate", {})
                if coord:
                    try:
                        result["coordinate_x"] = float(coord.get("x", 0))
                        result["coordinate_y"] = float(coord.get("y", 0))
                    except (TypeError, ValueError):
                        pass

        # APOLLO에서 영업시간 (구조화 데이터)
        if apollo:
            rq = apollo.get("ROOT_QUERY", {})
            NaverDataParser._parse_hours_from_apollo(rq, result)

        # APOLLO에서 못 가져온 경우 DOM 폴백
        if not result["operating_hours"]:
            result = NaverDataParser._parse_home_hours_dom(html, result)

        # DOM에서 링크
        result = NaverDataParser._parse_home_links_dom(html, result)

        return result

    @staticmethod
    def _parse_hours_from_apollo(root_query: dict, result: dict) -> None:
        """APOLLO newBusinessHours에서 구조화된 영업시간 추출

        newBusinessHours({"format":"hospital"}) → [
          {
            "businessHours": [
              {"day": "월", "businessHours": {"start": "09:30", "end": "19:00"},
               "breakHours": [{"start": "13:00", "end": "14:00"}],
               "description": null or "정기휴무 (매주 일요일)"}
            ],
            "comingIrregularClosedDays": [...],
            "comingRegularClosedDays": "...",
            "freeText": "...",
            "businessStatusDescription": {"status": "진료 중", ...}
          }
        ]
        """
        for k, v in root_query.items():
            if "placeDetail" not in k or not isinstance(v, dict):
                continue

            # newBusinessHours 키 찾기
            biz_hours_data = None
            for sub_k, sub_v in v.items():
                if "newBusinessHours" in sub_k and isinstance(sub_v, list) and sub_v:
                    biz_hours_data = sub_v[0]  # 첫 번째 (보통 "기본")
                    break

            if not biz_hours_data:
                return

            bh_list = biz_hours_data.get("businessHours", [])
            if not bh_list:
                return

            # ── 요일별 영업시간 파싱 ──
            DAY_ORDER = {"월": 0, "화": 1, "수": 2, "목": 3, "금": 4, "토": 5, "일": 6}
            hours_by_day = {}
            break_hours = {}
            last_order = {}
            closed_days = []

            for entry in bh_list:
                day = entry.get("day", "")
                bh = entry.get("businessHours")
                desc = entry.get("description")

                if bh and isinstance(bh, dict):
                    start = bh.get("start", "")
                    end = bh.get("end", "")
                    if start and end:
                        hours_by_day[day] = f"{start}~{end}"

                    # 휴게시간
                    breaks = entry.get("breakHours", [])
                    if breaks:
                        br = breaks[0]
                        if isinstance(br, dict):
                            br_start = br.get("start", "")
                            br_end = br.get("end", "")
                            if br_start and br_end:
                                break_hours[day] = f"{br_start}~{br_end}"

                    # 접수마감
                    lot = entry.get("lastOrderTimes")
                    if lot and isinstance(lot, list) and lot:
                        lo = lot[0]
                        if isinstance(lo, dict):
                            lo_time = lo.get("time", "")
                            if lo_time:
                                last_order[day] = lo_time
                elif desc:
                    # 영업시간 없음 = 휴무일
                    closed_days.append(f"{day} ({desc})")

            # ── operating_hours 구성 ──
            operating_hours = {}

            # 요일 순서대로 정렬
            sorted_days = sorted(hours_by_day.items(), key=lambda x: DAY_ORDER.get(x[0], 9))
            for day, time_range in sorted_days:
                operating_hours[day] = time_range

            if operating_hours:
                result["operating_hours"] = operating_hours

            # ── 휴게시간 ──
            if break_hours:
                # 모든 요일 동일하면 하나로 합침
                unique_breaks = set(break_hours.values())
                if len(unique_breaks) == 1:
                    result["lunch_break"] = list(unique_breaks)[0]
                else:
                    sorted_breaks = sorted(break_hours.items(), key=lambda x: DAY_ORDER.get(x[0], 9))
                    result["lunch_break"] = {d: t for d, t in sorted_breaks}

            # ── 접수마감 ──
            if last_order:
                unique_lo = set(last_order.values())
                if len(unique_lo) == 1:
                    result["last_order"] = list(unique_lo)[0]
                else:
                    sorted_lo = sorted(last_order.items(), key=lambda x: DAY_ORDER.get(x[0], 9))
                    result["last_order"] = {d: t for d, t in sorted_lo}

            # ── 휴무일 ──
            if closed_days:
                result["closed_days"] = closed_days

            # 정기휴무
            regular = biz_hours_data.get("comingRegularClosedDays", "")
            if regular and isinstance(regular, str) and regular.strip():
                if result["closed_days"] is None:
                    result["closed_days"] = []
                if isinstance(result["closed_days"], list):
                    result["closed_days"].append(regular.strip())

            # 임시휴무 (설날, 추석 등)
            irregular = biz_hours_data.get("comingIrregularClosedDays", [])
            if irregular:
                if result["closed_days"] is None:
                    result["closed_days"] = []
                for item in irregular:
                    if isinstance(item, dict):
                        name = item.get("name", "")
                        start = item.get("startDate", "")
                        end = item.get("endDate", "")
                        if name:
                            if isinstance(result["closed_days"], list):
                                result["closed_days"].append(f"{name} ({start}~{end})")

            # 추가 안내
            free_text = biz_hours_data.get("freeText", "")
            if free_text and isinstance(free_text, str) and free_text.strip():
                if result["operating_hours"] and isinstance(result["operating_hours"], dict):
                    result["operating_hours"]["_note"] = free_text.strip()

            logger.debug(
                f"APOLLO 영업시간: {len(operating_hours)}요일 | "
                f"휴게: {'있음' if break_hours else '없음'} | "
                f"휴무: {len(closed_days)}건"
            )
            return  # 첫 placeDetail만

    @staticmethod
    def _parse_home_hours_dom(html: str, result: dict) -> dict:
        """DOM에서 영업시간, 휴게시간, 휴무일 추출

        구조:
          div.O8qbU.pSavy → 영업시간 블록
          div.w9QyJ.eYvyf → 휴무일 블록
        """
        soup = BeautifulSoup(html, "html.parser")

        # 영업시간 블록
        hours_block = soup.select_one("div.pSavy")
        if hours_block:
            hours_text = hours_block.get_text("\n", strip=True)
            result["operating_hours"] = {"raw_text": hours_text}

            # 휴게시간
            time_tag = hours_block.find("time")
            if time_tag:
                time_text = time_tag.get_text(strip=True)
                if "휴게" in time_text or "점심" in time_text:
                    result["lunch_break"] = time_text

            for blind in hours_block.find_all("span", class_="place_blind"):
                bt = blind.get_text(strip=True)
                if "휴게시간" in bt:
                    result["lunch_break"] = bt

        # 휴무일 블록
        holiday_block = soup.select_one("div.eYvyf")
        if holiday_block:
            em = holiday_block.find("em")
            if em and "휴무" in em.get_text(strip=True):
                rest = holiday_block.get_text(" ", strip=True)
                rest = re.sub(r"^휴무일\s*", "", rest).strip()
                rest = re.sub(r"\s*안내$", "", rest).strip()
                result["closed_days"] = rest

        # 폴백: 텍스트 기반
        if not result["operating_hours"]:
            for el in soup.find_all(string=re.compile("영업시간")):
                parent = el.parent
                for _ in range(5):
                    if parent and parent.parent:
                        parent = parent.parent
                txt = parent.get_text("\n", strip=True) if parent else ""
                if len(txt) > 10:
                    result["operating_hours"] = {"raw_text": txt[:500]}
                    break

        return result

    @staticmethod
    def _parse_home_links_dom(html: str, result: dict) -> dict:
        """DOM에서 홈페이지/블로그 링크 추출 (div.O8qbU.yIPfO)"""
        soup = BeautifulSoup(html, "html.parser")
        link_block = soup.select_one("div.yIPfO")
        if link_block:
            for a in link_block.find_all("a", href=True):
                href = a["href"]
                if not href.startswith("http"):
                    continue
                href_lower = href.lower()
                if "blog.naver.com" in href_lower:
                    result["blog_url"] = result.get("blog_url") or href
                elif "naver.com/hospital" not in href_lower:
                    result["homepage_url"] = result.get("homepage_url") or href
        return result

    # ──────────────────────────────────────────────
    # 4. Information 페이지 파싱
    # ──────────────────────────────────────────────

    @staticmethod
    def parse_information(html: str) -> dict:
        """information 페이지에서 소개, 주차, SNS 링크 추출

        DOM 구조:
          div.place_section.OK1ft → 소개 텍스트
          div.place_section.IrpYf → 주차 정보
          div.place_section.qgcZG → SNS 링크
        """
        result = {
            "description": None,
            "parking_available": None,
            "parking_detail": None,
            "youtube_url": None,
            "instagram_url": None,
            "blog_url": None,
            "booking_url": None,
            "kakao_url": None,
            "homepage_url": None,
            "other_links": [],
        }

        soup = BeautifulSoup(html, "html.parser")

        # 소개
        intro_section = soup.select_one("div.OK1ft")
        if intro_section:
            content = intro_section.find("div", class_="place_section_content")
            if content:
                result["description"] = content.get_text("\n", strip=True)
            else:
                text = intro_section.get_text("\n", strip=True)
                text = re.sub(r"^소개\s*\n?", "", text).strip()
                result["description"] = text

        # 소개 폴백
        if not result["description"]:
            for el in soup.find_all(string=re.compile("^소개$")):
                parent = el.parent
                for _ in range(3):
                    if parent and parent.parent:
                        parent = parent.parent
                txt = parent.get_text("\n", strip=True) if parent else ""
                txt = re.sub(r"^소개\s*\n?", "", txt).strip()
                if len(txt) > 10:
                    result["description"] = txt[:2000]
                    break

        # 주차
        parking_section = soup.select_one("div.IrpYf")
        if parking_section:
            text = parking_section.get_text(" ", strip=True)
            result["parking_detail"] = text
            result["parking_available"] = any(
                kw in text for kw in ["가능", "있", "무료", "주차가능"]
            )

        # 주차 폴백
        if result["parking_detail"] is None:
            for el in soup.find_all(string="주차"):
                parent = el.parent
                for _ in range(3):
                    if parent and parent.parent:
                        parent = parent.parent
                txt = parent.get_text(" ", strip=True) if parent else ""
                if "주차" in txt and len(txt) < 200:
                    result["parking_detail"] = txt
                    result["parking_available"] = any(
                        kw in txt for kw in ["가능", "있", "무료"]
                    )
                    break

        # SNS 링크
        sns_section = soup.select_one("div.qgcZG")
        if sns_section:
            for a in sns_section.find_all("a", href=True):
                href = a["href"]
                if href.startswith("http"):
                    NaverDataParser._classify_link(href, result)

        # SNS 폴백
        if not any([result["youtube_url"], result["instagram_url"],
                     result["blog_url"], result["homepage_url"]]):
            for a in soup.find_all("a", href=True):
                href = a["href"]
                if href.startswith("http") and "naver.com/hospital" not in href:
                    NaverDataParser._classify_link(href, result)

        return result

    @staticmethod
    def _classify_link(url: str, result: dict) -> None:
        """URL을 카테고리별로 분류"""
        url_lower = url.lower()
        skip = [
            "nmap.place.naver", "policy.naver.com", "help.naver.com",
            "smartplace.naver.com", "m.place.naver.com/my",
            "m.naver.com", "ssl.pstatic.net",
        ]
        if any(p in url_lower for p in skip):
            return
        if "youtube.com" in url_lower or "youtu.be" in url_lower:
            result["youtube_url"] = result.get("youtube_url") or url
        elif "instagram.com" in url_lower:
            result["instagram_url"] = result.get("instagram_url") or url
        elif "blog.naver.com" in url_lower or "m.blog.naver.com" in url_lower:
            result["blog_url"] = result.get("blog_url") or url
        elif "booking.naver.com" in url_lower:
            result["booking_url"] = result.get("booking_url") or url
        elif "pf.kakao.com" in url_lower or "kakao" in url_lower:
            result["kakao_url"] = result.get("kakao_url") or url
        else:
            if not result.get("homepage_url") and not url_lower.endswith(".js"):
                result["homepage_url"] = url
            elif url not in result.get("other_links", []):
                result.setdefault("other_links", []).append(url)

    # ──────────────────────────────────────────────
    # 5. Photo 페이지 파싱
    # ──────────────────────────────────────────────

    @staticmethod
    def parse_photos(html: str, place_id: str = "") -> dict:
        """photo 페이지에서 업체등록 사진 URL 추출 (APOLLO 우선, DOM 폴백)

        APOLLO_STATE → placeDetail → images({"source":["ugcModeling"]})
        에서 업체등록 사진 전체 목록을 가져옵니다.
        APOLLO 실패 시 DOM <img> 태그에서 폴백합니다.
        """
        result = {
            "photos": [],
            "photo_count": 0,
            "total_on_page": 0,
            "has_more": False,
            "source": "none",
        }

        # ── 1) APOLLO_STATE에서 추출 (안정적) ──
        apollo = NaverDataParser.extract_apollo_state(html)
        if apollo:
            rq = apollo.get("ROOT_QUERY", {})
            for k, v in rq.items():
                if "placeDetail" not in k or not isinstance(v, dict):
                    continue
                for sub_k, sub_v in v.items():
                    if "ugcModeling" not in sub_k:
                        continue
                    if not isinstance(sub_v, dict):
                        continue
                    imgs = sub_v.get("images", [])
                    total = sub_v.get("totalImages", 0)
                    for img in imgs:
                        if isinstance(img, dict):
                            origin = img.get("origin", "")
                            if origin:
                                result["photos"].append(origin)
                    result["total_on_page"] = int(total) if total else len(result["photos"])
                    break

            if result["photos"]:
                result["photo_count"] = len(result["photos"])
                result["has_more"] = result["total_on_page"] > len(result["photos"])
                result["source"] = "apollo"
                logger.debug(
                    f"[{place_id}] APOLLO 사진: {result['photo_count']}장 "
                    f"(전체: {result['total_on_page']})"
                )
                return result

        # ── 2) DOM 폴백 (APOLLO 실패 시) ──
        soup = BeautifulSoup(html, "html.parser")
        seen = set()
        for img in soup.find_all("img"):
            src = img.get("src", "") or img.get("data-src", "")
            if not src or "ldb-phinf.pstatic.net" not in src:
                continue
            parent_html = str(img.parent)[:300].lower()
            alt = (img.get("alt", "") or "").lower()
            if "video" in parent_html or "video" in alt:
                continue
            high_res = NaverDataParser._to_high_res(src)
            if high_res not in seen:
                seen.add(high_res)
                result["photos"].append(high_res)

        result["photo_count"] = len(result["photos"])
        result["total_on_page"] = result["photo_count"]
        result["has_more"] = result["photo_count"] >= 5
        result["source"] = "dom" if result["photos"] else "none"
        return result

    @staticmethod
    def _to_high_res(url: str) -> str:
        """썸네일 URL → 고해상도 URL 변환"""
        url = re.sub(r"type=w\d+_?\w*", "type=w750", url)
        url = re.sub(r"type=f\d+_\d+", "type=w750", url)
        url = re.sub(r"type=s\d+", "type=w750", url)
        return url
