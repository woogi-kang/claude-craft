"""좌표 기반 병원 매칭 v2.2

3-Tier 매칭 전략:
  Tier 1: 이름 검색 → 후보 1개 → 바로 사용
  Tier 2: 이름+지역 검색 → 후보 축소
  Tier 3: 후보별 /home 방문 → APOLLO 좌표 → CSV 좌표 매칭

좌표 정밀도:
  - CSV naver_mapx/mapy: 정수 (÷10^7 = 소수점 7자리)
  - APOLLO coordinate.x/y: 문자열 (소수점 7자리)
  - 동일 소스 → 오차 0~1m
"""

import math
import re
from typing import Optional

from core.logger import logger
from core.config import (
    MATCH_THRESHOLD_EXACT, MATCH_THRESHOLD_HIGH,
    MATCH_THRESHOLD_MODERATE, MATCH_THRESHOLD_MAX,
)


def haversine_distance(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    """두 좌표 간 거리(미터) — Haversine 공식"""
    R = 6_371_000
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lng2 - lng1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def naver_coord_to_latlng(mapx: float, mapy: float) -> tuple:
    """네이버 CSV 좌표계 → (위도, 경도) 변환

    CSV: mapx=1269562840 (경도×10^7), mapy=374796070 (위도×10^7)
    변환: lat = mapy / 10^7,  lng = mapx / 10^7
    """
    return mapy / 1e7, mapx / 1e7


def match_by_coordinates(
    csv_mapx: float,
    csv_mapy: float,
    candidates: list,
    threshold_m: float = MATCH_THRESHOLD_MAX,
) -> Optional[dict]:
    """후보 목록에서 CSV 좌표와 가장 가까운 플레이스 반환

    Args:
        csv_mapx: CSV의 naver_mapx (경도×10^7)
        csv_mapy: CSV의 naver_mapy (위도×10^7)
        candidates: [{"place_id": str, "lat": float, "lng": float, ...}]
        threshold_m: 최대 허용 거리 (미터)

    Returns:
        매칭된 후보 dict (match_distance_m, match_confidence 추가)
        또는 None (매칭 실패)
    """
    target_lat, target_lng = naver_coord_to_latlng(csv_mapx, csv_mapy)
    best, best_dist = None, float("inf")

    for c in candidates:
        c_lat, c_lng = c.get("lat"), c.get("lng")
        if c_lat is None or c_lng is None:
            continue
        dist = haversine_distance(target_lat, target_lng, float(c_lat), float(c_lng))
        c["_distance_m"] = round(dist, 1)  # 디버깅용

        if dist < best_dist:
            best, best_dist = c, dist

    if best is None:
        logger.warning("좌표 매칭 실패: 유효한 좌표를 가진 후보 없음")
        return None

    if best_dist > threshold_m:
        logger.warning(
            f"좌표 매칭 실패: 최근접 {best_dist:.0f}m > 임계값 {threshold_m}m "
            f"(place_id={best.get('place_id')})"
        )
        return None

    best["match_distance_m"] = round(best_dist, 1)
    best["match_confidence"] = _distance_to_confidence(best_dist)
    logger.debug(
        f"좌표 매칭 성공: {best_dist:.1f}m, "
        f"신뢰도={best['match_confidence']:.2f}, "
        f"place_id={best.get('place_id')}"
    )
    return best


def match_best_candidate(
    csv_row: dict,
    candidates: list,
    threshold_m: float = MATCH_THRESHOLD_MAX,
) -> Optional[dict]:
    """CSV 행과 후보 목록으로 최적 매칭 수행 (종합 판단)

    이름 유사도 + 주소 유사도 + 좌표 거리를 종합 점수화.

    Args:
        csv_row: CSV 행 {"naver_name", "naver_mapx", "naver_mapy", "naver_address"}
        candidates: [{"place_id", "name", "address", "lat", "lng"}]

    Returns:
        최적 매칭 후보 dict 또는 None
    """
    csv_name = csv_row.get("naver_name", "")
    csv_addr = csv_row.get("naver_address", "")
    csv_mapx = float(csv_row.get("naver_mapx", 0))
    csv_mapy = float(csv_row.get("naver_mapy", 0))

    if csv_mapx == 0 or csv_mapy == 0:
        logger.warning(f"CSV 좌표 없음: {csv_name}")
        return None

    target_lat, target_lng = naver_coord_to_latlng(csv_mapx, csv_mapy)
    scored = []

    for c in candidates:
        score = 0.0
        details = {}

        # 1) 좌표 거리 점수 (0~50점)
        c_lat, c_lng = c.get("lat"), c.get("lng")
        if c_lat is not None and c_lng is not None:
            dist = haversine_distance(target_lat, target_lng, float(c_lat), float(c_lng))
            details["distance_m"] = round(dist, 1)

            if dist <= 10:
                score += 50  # 거의 완벽 (동일 좌표원)
            elif dist <= MATCH_THRESHOLD_EXACT:
                score += 40
            elif dist <= MATCH_THRESHOLD_HIGH:
                score += 25
            elif dist <= MATCH_THRESHOLD_MODERATE:
                score += 15
            elif dist <= MATCH_THRESHOLD_MAX:
                score += 5
            # >500m → 0점
        else:
            details["distance_m"] = None

        # 2) 이름 유사도 (0~30점)
        c_name = c.get("name", "")
        if c_name:
            nsim = name_similarity(csv_name, c_name)
            score += nsim * 30
            details["name_sim"] = round(nsim, 2)

        # 3) 주소 유사도 (0~20점)
        c_addr = c.get("address", "")
        if c_addr and csv_addr:
            asim = address_similarity(csv_addr, c_addr)
            score += asim * 20
            details["addr_sim"] = round(asim, 2)

        c["_match_score"] = round(score, 1)
        c["_match_details"] = details
        scored.append((score, c))

    if not scored:
        return None

    # 최고 점수 후보
    scored.sort(key=lambda x: -x[0])
    best_score, best = scored[0]

    # 최소 점수 기준: 좌표 매칭만이라도 40점 이상이면 OK
    if best_score < 15:
        logger.warning(
            f"매칭 점수 부족: {csv_name} → 최고점 {best_score:.1f} "
            f"(place_id={best.get('place_id')})"
        )
        return None

    best["match_distance_m"] = best.get("_match_details", {}).get("distance_m")
    best["match_confidence"] = min(best_score / 50, 1.0)
    best["match_score"] = best_score

    # 2위와의 점수 차이 (모호성 판단)
    if len(scored) > 1:
        gap = best_score - scored[1][0]
        best["match_gap"] = round(gap, 1)
        if gap < 5:
            logger.warning(
                f"모호한 매칭: {csv_name} → 1위 {best_score:.1f} vs 2위 {scored[1][0]:.1f} "
                f"(gap={gap:.1f})"
            )

    return best


def _distance_to_confidence(distance_m: float) -> float:
    """거리 → 신뢰도 변환"""
    if distance_m <= MATCH_THRESHOLD_EXACT:
        return 1.0
    elif distance_m <= MATCH_THRESHOLD_HIGH:
        return 0.8
    elif distance_m <= MATCH_THRESHOLD_MODERATE:
        return 0.5
    else:
        return 0.3


def normalize_name(name: str) -> str:
    """병원명 정규화 (비교용)"""
    name = re.sub(r"\s+", "", name)
    name = re.sub(r"[()（）\[\]&·,.]", "", name)
    return name.lower()


def name_similarity(name1: str, name2: str) -> float:
    """두 병원명 유사도 (0.0~1.0)"""
    n1, n2 = normalize_name(name1), normalize_name(name2)
    if n1 == n2:
        return 1.0
    if n1 in n2 or n2 in n1:
        return 0.8
    # 문자 집합 유사도
    common = len(set(n1) & set(n2))
    total = max(len(set(n1)), len(set(n2)))
    return common / total if total > 0 else 0.0


def address_similarity(addr1: str, addr2: str) -> float:
    """두 주소 유사도 (0.0~1.0)

    시/도 일치 0.3 + 구/군 일치 0.3 + 도로명/동 일치 0.4
    """
    p1 = addr1.strip().split()
    p2 = addr2.strip().split()

    score = 0.0

    # 시/도
    if len(p1) >= 1 and len(p2) >= 1:
        # "서울특별시" vs "서울" 등 정규화
        r1 = _normalize_region(p1[0])
        r2 = _normalize_region(p2[0])
        if r1 == r2:
            score += 0.3

    # 구/군/시
    if len(p1) >= 2 and len(p2) >= 2:
        if p1[1] == p2[1]:
            score += 0.3
        elif _extract_gu(p1[1]) == _extract_gu(p2[1]):
            score += 0.2

    # 나머지 토큰 교집합
    rest1 = set(p1[2:]) if len(p1) > 2 else set()
    rest2 = set(p2[2:]) if len(p2) > 2 else set()
    if rest1 and rest2:
        overlap = len(rest1 & rest2)
        total = max(len(rest1), len(rest2))
        score += 0.4 * (overlap / total)

    return score


def _normalize_region(region: str) -> str:
    """시/도명 정규화"""
    mapping = {
        "서울특별시": "서울", "부산광역시": "부산", "대구광역시": "대구",
        "인천광역시": "인천", "광주광역시": "광주", "대전광역시": "대전",
        "울산광역시": "울산", "세종특별자치시": "세종",
        "경기도": "경기", "강원특별자치도": "강원", "강원도": "강원",
        "충청북도": "충북", "충청남도": "충남",
        "전북특별자치도": "전북", "전라북도": "전북",
        "전라남도": "전남", "경상북도": "경북", "경상남도": "경남",
        "제주특별자치도": "제주",
    }
    return mapping.get(region, region[:2])


def _extract_gu(gu_str: str) -> str:
    """구/군/시 핵심 추출: '관악구' → '관악', '수원시' → '수원'"""
    for suffix in ["특별자치시", "광역시", "시", "구", "군"]:
        if gu_str.endswith(suffix):
            return gu_str[:-len(suffix)]
    return gu_str


def extract_region(address: str) -> tuple:
    """주소 → (시/도, 구/군)"""
    parts = address.strip().split()
    return (parts[0] if len(parts) >= 1 else "", parts[1] if len(parts) >= 2 else "")


def build_search_queries(csv_row: dict) -> list:
    """CSV 행에서 3-Tier 검색 쿼리 생성

    Returns:
        [
            {"tier": 1, "query": "고은미인의원 병원"},
            {"tier": 2, "query": "고은미인의원 관악구 병원"},
            {"tier": 2, "query": "고은미인의원 서울 병원"},
        ]
    """
    name = csv_row.get("naver_name", "")
    address = csv_row.get("naver_address", "")
    sido, gugun = extract_region(address)

    queries = [
        {"tier": 1, "query": f"{name} 병원"},
    ]

    if gugun:
        queries.append({"tier": 2, "query": f"{name} {gugun} 병원"})
    if sido:
        short_sido = _normalize_region(sido)
        queries.append({"tier": 2, "query": f"{name} {short_sido} 병원"})

    return queries
