"""실시간 진행률 모니터링"""
import time
from core.checkpoint_db import CheckpointDB


class ProgressMonitor:
    def __init__(self, db: CheckpointDB):
        self.db = db
        self.start_time = time.time()

    def print_status(self):
        stats = self.db.get_status_counts()
        elapsed = time.time() - self.start_time
        completed = stats.get("completed", 0)
        total = stats.get("total", 1)
        rate = completed / (elapsed / 3600) if elapsed > 0 else 0
        remaining = (total - completed) / max(rate, 0.01)

        print(f"""
╔══════════════════════════════════════════════╗
║  네이버 플레이스 크롤링 진행 상황              ║
╠══════════════════════════════════════════════╣
║  전체: {total:>5,}건                          ║
║  ✅ 성공: {stats.get('success',0):>4}  ⚠️ 부분: {stats.get('partial',0):>4}  ❌ 실패: {stats.get('failed',0):>4} ║
║  ⏳ 대기: {stats.get('pending',0):>4}  🔄 진행: {stats.get('crawling',0):>4}  🆔 ID: {stats.get('id_found',0):>4}  ║
║  ─────────────────────────────────────────   ║
║  진행률: {completed/total*100:>5.1f}% | 속도: {rate:>.0f}건/시간        ║
║  경과: {elapsed/3600:>.1f}h | 잔여: {remaining:>.1f}h                ║
║  📷 사진: {stats.get('photo_count',0):>6,}장                     ║
╚══════════════════════════════════════════════╝""")

    def print_summary(self):
        stats = self.db.get_status_counts()
        elapsed = time.time() - self.start_time
        print(f"\n{'='*50}")
        print(f"  최종 요약")
        print(f"{'='*50}")
        print(f"  총 소요 시간: {elapsed/3600:.1f}시간")
        print(f"  성공: {stats.get('success',0)}/{stats.get('total',0)}")
        print(f"  부분 성공: {stats.get('partial',0)}")
        print(f"  실패: {stats.get('failed',0)}")
        print(f"  사진: {stats.get('photo_count',0)}장")
        print(f"{'='*50}")
