"""중앙 설정 관리"""
from pathlib import Path

# === 경로 ===
PROJECT_ROOT = Path(__file__).parent.parent
RESULTS_DIR = PROJECT_ROOT / "results"
PHOTOS_DIR = RESULTS_DIR / "photos"
PHOTO_DIR = PHOTOS_DIR  # 별칭
DB_DIR = RESULTS_DIR / "db"
DB_PATH = DB_DIR / "crawl.db"
LOGS_DIR = RESULTS_DIR / "logs"
RAW_HTML_DIR = RESULTS_DIR / "html_dump"
INPUT_CSV = PROJECT_ROOT / "input" / "skin_clinics.csv"

# === Rate Limiting ===
# ── 속도 제어 (차단 방지) ──
# 같은 병원 내 페이지 이동 (home→info→photo)
REQUEST_DELAY_MIN = 2.5
REQUEST_DELAY_MAX = 5.5
# 병원 간 전환 (크롤링 완료 → 다음 병원 검색)
PAGE_READ_DELAY_MIN = 3.0
PAGE_READ_DELAY_MAX = 7.0
# 배치 쿨다운: N건마다 긴 휴식
BATCH_SIZE = 40
BATCH_COOLDOWN_MIN = 90
BATCH_COOLDOWN_MAX = 180
# 지역 전환 시 긴 쿨다운
REGION_COOLDOWN = 300

# === HTTP 세션 ===
MAX_REQUESTS_PER_SESSION = 200
SESSION_ROTATE_COOLDOWN = 10
HTTP_TIMEOUT = 30.0

# === 재시도 ===
MAX_RETRIES = 3
RETRY_BACKOFF_BASE = 5.0
RETRY_BACKOFF_MULTIPLIER = 3.0
BLOCK_DETECT_WAIT_TIMES = [60, 180, 600, 1800]
BLOCK_MAX_CONSECUTIVE = 10

# === 사진 ===
PHOTO_CONCURRENT_LIMIT = 5

# === 좌표 매칭 ===
MATCH_THRESHOLD_EXACT = 100       # 확정 (m)
MATCH_THRESHOLD_HIGH = 200        # 높은 신뢰도
MATCH_THRESHOLD_MODERATE = 300    # 보통
MATCH_THRESHOLD_MAX = 500         # 최대 허용

# === 사진 ===
PHOTO_DOWNLOAD_CONCURRENT = 5
PHOTO_MIN_SIZE_BYTES = 1024

# === 모바일 User-Agent ===
MOBILE_USER_AGENTS = [
    (
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) "
        "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 "
        "Mobile/15E148 Safari/604.1"
    ),
    (
        "Mozilla/5.0 (Linux; Android 14; SM-S928B) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 "
        "Mobile Safari/537.36"
    ),
    (
        "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 "
        "Mobile Safari/537.36"
    ),
    (
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) "
        "AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/122.0.6261.89 "
        "Mobile/15E148 Safari/604.1"
    ),
]

# === 네이버 URL ===
NAVER_SEARCH_URL = "https://m.search.naver.com/search.naver"
NAVER_PLACE_BASE = "https://m.place.naver.com/hospital"
NAVER_BOOKING_PATTERN = "https://booking.naver.com/booking/13/bizes/{place_id}"

# === 지역 배치 순서 ===
REGION_BATCH_ORDER = [
    "서울특별시", "경기도", "인천광역시", "부산광역시",
    "대구광역시", "광주광역시", "대전광역시", "울산광역시",
    "세종특별자치시", "경상남도", "충청남도", "전북특별자치도",
    "경상북도", "충청북도", "전라남도", "강원특별자치도",
    "제주특별자치도",
]
