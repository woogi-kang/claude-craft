"""
SQLite 체크포인트 DB
크롤링 진행 상태, 결과를 실시간으로 저장합니다.
"""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path

from core.logger import logger
from core.config import DB_PATH


class CheckpointDB:
    def __init__(self, db_path: Path | str | None = None):
        self.db_path = Path(db_path) if db_path else DB_PATH
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: sqlite3.Connection | None = None
        self._init_db()

    def _get_conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(str(self.db_path))
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
        return self._conn

    def _init_db(self) -> None:
        conn = self._get_conn()
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS hospitals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                csv_no INTEGER NOT NULL,
                naver_name TEXT NOT NULL,
                naver_address TEXT,
                csv_mapx REAL,
                csv_mapy REAL,
                place_id TEXT,
                match_tier INTEGER,
                match_confidence REAL,
                match_distance_m REAL,
                match_method TEXT,
                operating_hours_json TEXT,
                lunch_break TEXT,
                last_order TEXT,
                closed_days_json TEXT,
                amenities_json TEXT,
                description TEXT,
                parking_available INTEGER,
                parking_detail TEXT,
                youtube_url TEXT,
                instagram_url TEXT,
                blog_url TEXT,
                booking_url TEXT,
                kakao_url TEXT,
                homepage_url TEXT,
                other_links_json TEXT,
                photo_count INTEGER DEFAULT 0,
                photo_dir TEXT,
                home_url TEXT,
                information_url TEXT,
                photo_page_url TEXT,
                crawl_status TEXT DEFAULT 'pending',
                crawl_started_at TEXT,
                crawl_completed_at TEXT,
                error_messages_json TEXT DEFAULT '[]',
                validation_status TEXT,
                UNIQUE(csv_no)
            );
            CREATE TABLE IF NOT EXISTS photos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                hospital_id INTEGER REFERENCES hospitals(id),
                place_id TEXT NOT NULL,
                photo_index INTEGER,
                original_url TEXT,
                local_path TEXT,
                file_size INTEGER,
                download_status TEXT DEFAULT 'pending',
                is_video INTEGER DEFAULT 0,
                downloaded_at TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_hospitals_status ON hospitals(crawl_status);
            CREATE INDEX IF NOT EXISTS idx_hospitals_place_id ON hospitals(place_id);
            CREATE INDEX IF NOT EXISTS idx_photos_hospital ON photos(hospital_id);
        """)
        conn.commit()
        logger.debug("DB initialized: {}", self.db_path)

    # ── 삽입 ──

    def bulk_insert_hospitals(self, rows: list[dict]) -> int:
        conn = self._get_conn()
        conn.executemany(
            """INSERT OR IGNORE INTO hospitals
               (csv_no, naver_name, naver_address, csv_mapx, csv_mapy)
               VALUES (:csv_no, :naver_name, :naver_address, :csv_mapx, :csv_mapy)""",
            rows,
        )
        conn.commit()
        count = conn.execute("SELECT COUNT(*) FROM hospitals").fetchone()[0]
        logger.info("Bulk inserted. Total: {}", count)
        return count

    # ── Skill 1 ──

    def update_place_id(self, csv_no: int, place_id: str,
                        match_tier: int, match_confidence: float,
                        match_distance_m: float | None = None,
                        match_method: str | None = None) -> None:
        conn = self._get_conn()
        conn.execute(
            """UPDATE hospitals SET place_id=?, match_tier=?, match_confidence=?,
               match_distance_m=?, match_method=?, crawl_status='id_found'
               WHERE csv_no=?""",
            (place_id, match_tier, match_confidence, match_distance_m, match_method, csv_no),
        )
        conn.commit()

    # ── Skill 2 ──

    def update_home_data(self, csv_no: int, operating_hours=None,
                         lunch_break=None, last_order=None,
                         closed_days=None, amenities=None) -> None:
        conn = self._get_conn()
        # lunch_break, last_order가 dict면 JSON 직렬화
        lb_val = json.dumps(lunch_break, ensure_ascii=False) if isinstance(lunch_break, dict) else lunch_break
        lo_val = json.dumps(last_order, ensure_ascii=False) if isinstance(last_order, dict) else last_order
        conn.execute(
            """UPDATE hospitals SET operating_hours_json=?, lunch_break=?,
               last_order=?, closed_days_json=?, amenities_json=? WHERE csv_no=?""",
            (
                json.dumps(operating_hours, ensure_ascii=False) if operating_hours else None,
                lb_val,
                lo_val,
                json.dumps(closed_days, ensure_ascii=False) if closed_days else None,
                json.dumps(amenities, ensure_ascii=False) if amenities else None,
                csv_no,
            ),
        )
        conn.commit()

    # ── Skill 3 ──

    def update_info_data(self, csv_no: int, **kwargs) -> None:
        conn = self._get_conn()
        fields, values = [], []
        for key in ["description", "parking_available", "parking_detail",
                     "youtube_url", "instagram_url", "blog_url",
                     "booking_url", "kakao_url", "homepage_url"]:
            if key in kwargs:
                fields.append(f"{key}=?")
                values.append(kwargs[key])
        if "other_links" in kwargs and kwargs["other_links"]:
            fields.append("other_links_json=?")
            values.append(json.dumps(kwargs["other_links"], ensure_ascii=False))
        if fields:
            values.append(csv_no)
            conn.execute(f"UPDATE hospitals SET {', '.join(fields)} WHERE csv_no=?", values)
            conn.commit()

    # ── Skill 4 ──

    def update_photo_count(self, csv_no: int, photo_count: int, photo_dir: str | None = None) -> None:
        conn = self._get_conn()
        conn.execute("UPDATE hospitals SET photo_count=?, photo_dir=? WHERE csv_no=?",
                     (photo_count, photo_dir, csv_no))
        conn.commit()

    def update_urls(self, csv_no: int, home_url: str = None,
                    information_url: str = None, photo_page_url: str = None) -> None:
        """크롤링에 사용된 실제 URL 저장 (검증용)"""
        conn = self._get_conn()
        conn.execute(
            "UPDATE hospitals SET home_url=?, information_url=?, photo_page_url=? WHERE csv_no=?",
            (home_url, information_url, photo_page_url, csv_no),
        )
        conn.commit()

    def insert_photo(self, hospital_id: int, place_id: str, photo_index: int,
                     original_url: str, local_path: str | None = None,
                     file_size: int | None = None, download_status: str = "pending",
                     is_video: bool = False) -> int:
        conn = self._get_conn()
        cur = conn.execute(
            """INSERT INTO photos (hospital_id, place_id, photo_index, original_url,
               local_path, file_size, download_status, is_video, downloaded_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (hospital_id, place_id, photo_index, original_url, local_path,
             file_size, download_status, int(is_video),
             datetime.now().isoformat() if download_status == "success" else None),
        )
        conn.commit()
        return cur.lastrowid

    # ── 상태 ──

    def update_status(self, csv_no: int, status: str, error_msg: str | None = None) -> None:
        conn = self._get_conn()
        now = datetime.now().isoformat()
        if status == "crawling":
            conn.execute("UPDATE hospitals SET crawl_status=?, crawl_started_at=? WHERE csv_no=?",
                         (status, now, csv_no))
        elif status in ("success", "partial", "failed", "not_found"):
            conn.execute("UPDATE hospitals SET crawl_status=?, crawl_completed_at=? WHERE csv_no=?",
                         (status, now, csv_no))
        else:
            conn.execute("UPDATE hospitals SET crawl_status=? WHERE csv_no=?", (status, csv_no))
        if error_msg:
            row = conn.execute("SELECT error_messages_json FROM hospitals WHERE csv_no=?", (csv_no,)).fetchone()
            errors = json.loads(row["error_messages_json"]) if row and row["error_messages_json"] else []
            errors.append(f"[{now}] {error_msg}")
            conn.execute("UPDATE hospitals SET error_messages_json=? WHERE csv_no=?",
                         (json.dumps(errors, ensure_ascii=False), csv_no))
        conn.commit()

    # ── 조회 ──

    def get_pending(self, limit: int | None = None) -> list[dict]:
        conn = self._get_conn()
        sql = "SELECT * FROM hospitals WHERE crawl_status IN ('pending','id_found') ORDER BY id"
        if limit: sql += f" LIMIT {limit}"
        return [dict(r) for r in conn.execute(sql).fetchall()]

    def get_failed(self) -> list[dict]:
        return [dict(r) for r in self._get_conn().execute(
            "SELECT * FROM hospitals WHERE crawl_status='failed'").fetchall()]

    def get_by_csv_no(self, csv_no: int) -> dict | None:
        row = self._get_conn().execute("SELECT * FROM hospitals WHERE csv_no=?", (csv_no,)).fetchone()
        return dict(row) if row else None

    def get_hospital_id(self, csv_no: int) -> int | None:
        row = self._get_conn().execute("SELECT id FROM hospitals WHERE csv_no=?", (csv_no,)).fetchone()
        return row["id"] if row else None

    def get_status_summary(self) -> dict[str, int]:
        conn = self._get_conn()
        rows = conn.execute("SELECT crawl_status, COUNT(*) as cnt FROM hospitals GROUP BY crawl_status").fetchall()
        result = {r["crawl_status"]: r["cnt"] for r in rows}
        result["total"] = sum(result.values())
        result["completed"] = sum(result.get(s, 0) for s in ("success", "partial", "failed", "not_found"))
        result["photo_count"] = conn.execute("SELECT COALESCE(SUM(photo_count),0) FROM hospitals").fetchone()[0]
        return result

    def get_all_results(self) -> list[dict]:
        return [dict(r) for r in self._get_conn().execute("SELECT * FROM hospitals ORDER BY csv_no").fetchall()]

    def add_log(self, hospital_id, skill_name, status, message):
        self._get_conn().execute(
            "INSERT INTO crawl_log (hospital_id, skill_name, status, message) VALUES (?,?,?,?)",
            (hospital_id, skill_name, status, message))
        self._get_conn().commit()

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None
