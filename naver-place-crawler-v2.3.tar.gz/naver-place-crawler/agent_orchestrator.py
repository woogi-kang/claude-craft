"""에이전트 오케스트레이터 — 지역별 크롤링 파이프라인

실행 예시:
    # 단일 지역 크롤링
    python agent_orchestrator.py --region 서울특별시
    python agent_orchestrator.py --region 경기도
    python agent_orchestrator.py --region 부산광역시

    # 서울 구 단위 분할
    python agent_orchestrator.py --region 서울특별시 --subregion 강남구
    python agent_orchestrator.py --region 서울특별시 --subregion 서초구,송파구,강동구

    # 소규모 테스트
    python agent_orchestrator.py --region 제주특별자치도 --limit 5

    # 전체 (비추천 — 지역별 분할 권장)
    python agent_orchestrator.py --all

    # 실패건 재시도
    python agent_orchestrator.py --retry-failed

    # 진행 상태 확인
    python agent_orchestrator.py --status
"""
import asyncio
import csv
import json
import sys
import time
from pathlib import Path

from core.logger import logger

from core.config import (
    NAVER_SEARCH_URL, NAVER_PLACE_BASE, BATCH_SIZE,
    REGION_BATCH_ORDER, RESULTS_DIR, DB_PATH,
)
from core.http_client import NaverHTTPClient, BlockDetectedError
from core.checkpoint_db import CheckpointDB
from core.rate_limiter import RateLimiter
from core.retry_handler import retry_async, RetryExhausted
from core.naver_data_parser import NaverDataParser

from skills.skill_search_place_id import search_place_id, get_duplicate_names, SearchResult
from skills.skill_crawl_home import crawl_home
from skills.skill_crawl_information import crawl_information
from skills.skill_crawl_photos import crawl_photos
from skills.skill_export_results import export_all


class AgentOrchestrator:
    def __init__(self, csv_path: Path, db: CheckpointDB, output_dir: Path,
                 region_filter: str = "", subregion_filter: list = None,
                 limit: int = 0, skip_photos: bool = False):
        self.csv_path = csv_path
        self.db = db
        self.output_dir = output_dir
        self.region_filter = region_filter
        self.subregion_filter = subregion_filter or []
        self.limit = limit
        self.skip_photos = skip_photos

        self.client = NaverHTTPClient()
        self.limiter = RateLimiter()
        self.duplicate_names: set = set()
        self.consecutive_blocks = 0

    async def run(self):
        logger.info("=" * 60)
        logger.info("  네이버 플레이스 크롤링 에이전트 시작")
        logger.info(f"  지역: {self.region_filter or '전체'}")
        if self.subregion_filter:
            logger.info(f"  세부지역: {', '.join(self.subregion_filter)}")
        logger.info("=" * 60)

        # 1) CSV 로드 → DB 초기화
        rows = self._load_csv()
        self._init_db(rows)
        self.duplicate_names = get_duplicate_names(rows)
        logger.info(f"중복 이름 그룹: {len(self.duplicate_names)}개")

        # 2) 처리 대상 필터링
        pending = self._get_pending()
        if not pending:
            logger.info("처리할 병원 없음 (모두 완료되었거나 필터 조건에 해당 없음)")
            self._print_status()
            return

        logger.info(f"처리 대상: {len(pending)}건")

        # 3) 크롤링 실행
        await self.client.start()
        start_time = time.time()
        try:
            await self._process_items(pending)
        finally:
            await self.client.close()

        elapsed = time.time() - start_time
        logger.info(f"크롤링 완료: {elapsed/3600:.1f}시간 소요")

        # 4) 결과 내보내기
        self._print_status()
        logger.info("결과 내보내기...")
        export_all(self.db, self.output_dir)

    def _load_csv(self) -> list:
        with open(self.csv_path, "r", encoding="utf-8-sig") as f:
            rows = list(csv.DictReader(f))
        logger.info(f"CSV 로드: {len(rows)}행 ({self.csv_path})")
        return rows

    def _init_db(self, rows: list):
        """CSV 데이터를 DB에 초기 삽입 (중복 무시)"""
        db_rows = []
        for i, r in enumerate(rows):
            db_rows.append({
                "csv_no": i + 1,
                "naver_name": r.get("naver_name", r.get("병원/약국명", "")),
                "naver_address": r.get("naver_address", ""),
                "csv_mapx": float(r.get("naver_mapx", 0) or 0),
                "csv_mapy": float(r.get("naver_mapy", 0) or 0),
            })
        self.db.bulk_insert_hospitals(db_rows)

    def _get_pending(self) -> list:
        """지역 필터 적용된 처리 대상 목록"""
        all_pending = self.db.get_pending(limit=self.limit if self.limit else None)

        if self.region_filter:
            filtered = [p for p in all_pending
                        if (p.get("naver_address") or "").startswith(self.region_filter)]

            # 구/군 세부 필터
            if self.subregion_filter:
                filtered = [
                    p for p in filtered
                    if any(sub in (p.get("naver_address") or "")
                           for sub in self.subregion_filter)
                ]

            return filtered

        return all_pending

    async def _process_items(self, items: list):
        """병원 목록 순차 처리"""
        total = len(items)

        for i, item in enumerate(items):
            csv_no = item["csv_no"]
            name = item["naver_name"]
            addr = item.get("naver_address", "")[:40]

            logger.info(f"[{i+1}/{total}] {name} ({addr})")

            try:
                await self._process_one(item)
                self.consecutive_blocks = 0
            except BlockDetectedError as e:
                self.consecutive_blocks += 1
                logger.error(f"차단 감지 ({self.consecutive_blocks}회): {e}")

                if self.consecutive_blocks >= 5:
                    logger.critical("연속 차단 5회! 안전을 위해 에이전트를 중단합니다.")
                    logger.critical("30분 후 다시 시도하세요: --retry-failed 옵션 사용")
                    break

                await self.limiter.wait_blocked(self.consecutive_blocks)
                await self.client.force_rotate()
            except RetryExhausted as e:
                logger.error(f"재시도 소진: {name}: {e}")
                self.db.update_status(csv_no, "failed", str(e))
            except Exception as e:
                logger.error(f"예외: {name}: {type(e).__name__}: {e}")
                self.db.update_status(csv_no, "failed", f"{type(e).__name__}: {e}")

            # 병원 완료 후 딜레이 + 배치 쿨다운
            await self.limiter.hospital_done()

            # 10건마다 진행 상태 출력
            if (i + 1) % 10 == 0:
                self._print_progress(i + 1, total)

    async def _process_one(self, item: dict):
        """단일 병원 전체 파이프라인"""
        csv_no = item["csv_no"]
        name = item["naver_name"]

        # CSV 원본 행 재구성 (search_place_id에 전달)
        csv_row = {
            "naver_name": name,
            "naver_address": item.get("naver_address", ""),
            "naver_mapx": str(item.get("csv_mapx", 0)),
            "naver_mapy": str(item.get("csv_mapy", 0)),
        }

        self.db.update_status(csv_no, "crawling")

        # ── Skill 1: Place ID 검색 ──
        search_result = await search_place_id(
            self.client, self.limiter, csv_row,
            is_duplicate_name=(name in self.duplicate_names),
        )

        if not search_result.success:
            self.db.update_status(csv_no, "failed",
                                  f"ID 검색 실패: {search_result.match_method}")
            return

        place_id = search_result.place_id
        self.db.update_place_id(
            csv_no, place_id,
            search_result.match_tier,
            search_result.match_confidence,
            search_result.match_distance_m,
            search_result.match_method,
        )

        # ── Skill 2: Home ──
        # Tier 3에서 이미 home 데이터를 가져왔으면 재활용
        home_data = search_result.home_data
        if not home_data:
            await self.limiter.page_delay()
            try:
                home_data = await crawl_home(self.client, place_id)
            except Exception as e:
                logger.warning(f"[{csv_no}] Home 실패: {e}")
                home_data = {}

        if home_data:
            self.db.update_home_data(
                csv_no,
                operating_hours=home_data.get("operating_hours"),
                lunch_break=home_data.get("lunch_break"),
                last_order=home_data.get("last_order"),
                closed_days=home_data.get("closed_days"),
                amenities=home_data.get("amenities"),
            )

        # ── Skill 3: Information ──
        await self.limiter.page_delay()
        home_url = f"{NAVER_PLACE_BASE}/{place_id}/home"
        info_url = f"{NAVER_PLACE_BASE}/{place_id}/information"
        photo_page_url = f"{NAVER_PLACE_BASE}/{place_id}/photo?filterType=%EC%97%85%EC%B2%B4"
        try:
            info_data = await crawl_information(self.client, place_id, referer=home_url)
            if info_data:
                self.db.update_info_data(csv_no, **info_data)
        except Exception as e:
            logger.warning(f"[{csv_no}] Info 실패: {e}")

        # ── Skill 4: Photos ──
        if not self.skip_photos:
            await self.limiter.page_delay()
            try:
                photo_data = await crawl_photos(self.client, place_id, referer=home_url)
                self.db.update_photo_count(
                    csv_no,
                    photo_data.get("photo_count", 0),
                    photo_data.get("photo_dir"),
                )
            except Exception as e:
                logger.warning(f"[{csv_no}] Photo 실패: {e}")

        # ── URL 저장 (검증용) ──
        self.db.update_urls(csv_no, home_url=home_url,
                            information_url=info_url, photo_page_url=photo_page_url)

        self.db.update_status(csv_no, "success")
        logger.info(f"[{csv_no}] ✅ 완료: {name} (id={place_id}, "
                     f"tier={search_result.match_tier}, dist={search_result.match_distance_m}m)")

    def _print_progress(self, done: int, total: int):
        """진행 상태 출력"""
        stats = self.db.get_status_summary()
        pct = done / total * 100
        logger.info(
            f"── 진행: {done}/{total} ({pct:.0f}%) | "
            f"성공: {stats.get('success', 0)} | "
            f"실패: {stats.get('failed', 0)} | "
            f"요청: {self.limiter.stats['total_requests']}건 ──"
        )

    def _print_status(self):
        """최종 상태 출력"""
        stats = self.db.get_status_summary()
        logger.info("=" * 60)
        logger.info("  크롤링 상태 요약")
        logger.info("=" * 60)
        for status, cnt in sorted(stats.items()):
            if status not in ("total", "completed", "photo_count"):
                logger.info(f"  {status:15s}: {cnt:5d}건")
        logger.info(f"  {'─' * 30}")
        logger.info(f"  {'전체':15s}: {stats.get('total', 0):5d}건")
        logger.info(f"  {'완료':15s}: {stats.get('completed', 0):5d}건")
        logger.info(f"  {'사진':15s}: {stats.get('photo_count', 0):5d}장")


async def main():
    import argparse
    parser = argparse.ArgumentParser(
        description="네이버 플레이스 크롤링 에이전트 (지역별 분할 실행)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
사용 예시:
  # 제주부터 시작 (소규모 테스트)
  python agent_orchestrator.py --region 제주특별자치도

  # 서울 강남권
  python agent_orchestrator.py --region 서울특별시 --subregion 강남구,서초구,송파구

  # 경기도 전체
  python agent_orchestrator.py --region 경기도

  # 실패건만 재시도
  python agent_orchestrator.py --retry-failed

  # 현재 진행 상태 확인
  python agent_orchestrator.py --status
        """,
    )
    parser.add_argument("--input", "-i", default="input/skin_clinics.csv", help="입력 CSV")
    parser.add_argument("--output", "-o", default="results/", help="출력 디렉토리")
    parser.add_argument("--region", default="", help="시/도 필터 (예: 서울특별시)")
    parser.add_argument("--subregion", default="", help="구/군 필터, 콤마 구분 (예: 강남구,서초구)")
    parser.add_argument("--limit", type=int, default=0, help="최대 처리 건수 (0=전체)")
    parser.add_argument("--skip-photos", action="store_true", help="사진 크롤링 건너뛰기")
    parser.add_argument("--all", action="store_true", help="전체 크롤링 (비추천)")
    parser.add_argument("--retry-failed", action="store_true", help="실패건 재시도")
    parser.add_argument("--status", action="store_true", help="진행 상태만 확인")
    parser.add_argument("--db", default=None, help="DB 경로 (기본: results/crawl.db)")
    args = parser.parse_args()

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    db = CheckpointDB(args.db)

    try:
        # 상태 확인만
        if args.status:
            # DB에 데이터가 있는지 확인
            stats = db.get_status_summary()
            if stats.get("total", 0) == 0:
                print("DB가 비어있습니다. 먼저 크롤링을 실행하세요.")
            else:
                print("=" * 60)
                print("  크롤링 진행 상태")
                print("=" * 60)
                for status, cnt in sorted(stats.items()):
                    if status not in ("total", "completed", "photo_count"):
                        print(f"  {status:15s}: {cnt:5d}건")
                print(f"  {'─' * 30}")
                print(f"  {'전체':15s}: {stats.get('total', 0):5d}건")
                print(f"  {'완료':15s}: {stats.get('completed', 0):5d}건")
                print(f"  {'사진':15s}: {stats.get('photo_count', 0):5d}장")
            return

        # 실패건 재시도
        if args.retry_failed:
            failed = db.get_failed()
            if not failed:
                print("실패건이 없습니다.")
                return
            print(f"실패건 {len(failed)}건 재시도...")
            # 상태를 pending으로 리셋
            for item in failed:
                db.update_status(item["csv_no"], "pending")

        # 지역 필터 필수 체크 (--all 없으면)
        if not args.region and not args.all and not args.retry_failed:
            print("⚠️  --region 옵션으로 지역을 지정하세요.")
            print("   안전한 크롤링을 위해 지역별 분할 실행을 권장합니다.")
            print()
            print("   예: python agent_orchestrator.py --region 제주특별자치도")
            print("   전체: python agent_orchestrator.py --all (비추천)")
            return

        subregions = [s.strip() for s in args.subregion.split(",") if s.strip()]

        agent = AgentOrchestrator(
            csv_path=Path(args.input),
            db=db,
            output_dir=output_dir,
            region_filter=args.region,
            subregion_filter=subregions,
            limit=args.limit,
            skip_photos=args.skip_photos,
        )
        await agent.run()

    finally:
        db.close()


if __name__ == "__main__":
    asyncio.run(main())
