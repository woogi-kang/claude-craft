"""Phase 1 검증 스크립트 v2.2

HTTP-Only 전략 검증 (실제 JSON 구조 확인 완료):
  - 검색 → Place ID 추출 (/hospital/{id} 패턴)
  - /home → __APOLLO_STATE__ + DOM 파싱 (영업시간, 편의시설)
  - /information → DOM 파싱 (소개, 주차, SNS)
  - /photo → DOM 파싱 (사진 URL)
"""

import asyncio
import json
import sys
import time
from pathlib import Path

from core.config import RAW_HTML_DIR, RESULTS_DIR
from core.http_client import NaverHTTPClient
from core.naver_data_parser import NaverDataParser
from core.logger import get_logger

logger = get_logger("phase1")

# 테스트 대상 병원
TEST_HOSPITALS = [
    {"name": "고은미인의원", "region": "서울 관악구", "is_duplicate": False},
    {"name": "톡스앤필의원 관악서울대입구점", "region": "서울 관악구", "is_duplicate": False},
    {"name": "아름다운피부과의원", "region": "", "is_duplicate": True},
]


async def run_probe(custom_name: str = None):
    """Phase 1 검증 실행"""
    hospitals = TEST_HOSPITALS
    if custom_name:
        hospitals = [{"name": custom_name, "region": "", "is_duplicate": False}]

    Path(RAW_HTML_DIR).mkdir(parents=True, exist_ok=True)
    Path(RESULTS_DIR).mkdir(parents=True, exist_ok=True)

    client = NaverHTTPClient()
    await client.start()

    report = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "tests": [],
        "summary": {},
        "decision": "",
        "decision_detail": "",
    }

    search_ok = 0
    home_ok = 0
    info_ok = 0
    photo_ok = 0

    try:
        for idx, h in enumerate(hospitals):
            name = h["name"]
            print(f"\n{'=' * 60}")
            print(f"  Test {idx + 1}/{len(hospitals)}: {name}")
            print(f"{'=' * 60}")

            test_result = {"name": name, "search": {}, "home": {}, "information": {}, "photos": {}}

            # ── 1. 검색 → Place ID ──
            print(f"\n  📍 Test 1: 검색 → Place ID")
            query = name
            search_url = f"https://m.search.naver.com/search.naver?query={query} 병원&sm=mtp_hty.top&where=m"
            
            resp = await client.get(search_url)
            html = resp.text
            
            # HTML 저장
            safe_name = name.replace(" ", "_")[:20]
            html_path = Path(RAW_HTML_DIR) / f"search_{safe_name}.html"
            html_path.write_text(html, encoding="utf-8")

            candidates = NaverDataParser.parse_search_results(html)
            place_id = candidates[0]["place_id"] if candidates else None

            test_result["search"] = {
                "query": query,
                "http_status": resp.status_code,
                "candidates_found": len(candidates),
                "place_id": place_id,
                "html_size": len(html),
                "candidates_sample": candidates[:5],
            }

            if place_id:
                print(f"    ✅ Place ID: {place_id} ({len(candidates)} 후보)")
                search_ok += 1
            else:
                print(f"    ❌ Place ID 없음 (HTML: {len(html)}B)")
                print(f"  ❌ Place ID 없음 — 이후 테스트 스킵")
                report["tests"].append(test_result)
                if idx < len(hospitals) - 1:
                    print(f"  ⏳ 3초 대기...")
                    await asyncio.sleep(3)
                continue

            await asyncio.sleep(2)

            # ── 2. /home ──
            print(f"\n  🏠 Test 2: /home (ID: {place_id})")
            home_url = f"https://m.place.naver.com/hospital/{place_id}/home"
            resp = await client.get(home_url, referer=search_url)
            html = resp.text

            (Path(RAW_HTML_DIR) / f"home_{place_id}.html").write_text(html, encoding="utf-8")

            home_data = NaverDataParser.parse_home(html, place_id)
            apollo = NaverDataParser.extract_apollo_state(html)

            test_result["home"] = {
                "url": home_url,
                "http_status": resp.status_code,
                "has_apollo_state": apollo is not None,
                "html_size": len(html),
                "parsed_result": {},
            }

            if apollo:
                print(f"    ✅ __APOLLO_STATE__ | HTML: {len(html):,}B")
                home_ok += 1
            else:
                print(f"    ❌ __APOLLO_STATE__ 없음 | HTML: {len(html):,}B")

            for field in ["operating_hours", "lunch_break", "closed_days", "amenities",
                          "name", "road_address", "phone", "coordinate_x"]:
                val = home_data.get(field)
                status = "✅ found" if val else "❌ empty"
                test_result["home"]["parsed_result"][field] = status
                print(f"    {status.replace('found', '')} {field}: {str(val)[:60] if val else ''}")

            await asyncio.sleep(2)

            # ── 3. /information ──
            print(f"\n  ℹ️  Test 3: /information")
            info_url = f"https://m.place.naver.com/hospital/{place_id}/information"
            resp = await client.get(info_url, referer=home_url)
            html = resp.text

            (Path(RAW_HTML_DIR) / f"information_{place_id}.html").write_text(html, encoding="utf-8")

            info_data = NaverDataParser.parse_information(html)
            apollo2 = NaverDataParser.extract_apollo_state(html)

            test_result["information"] = {
                "url": info_url,
                "http_status": resp.status_code,
                "has_apollo_state": apollo2 is not None,
                "html_size": len(html),
                "parsed_result": {},
            }

            if apollo2:
                info_ok += 1

            for field in ["description", "parking_available", "parking_detail",
                          "youtube_url", "instagram_url", "blog_url",
                          "booking_url", "kakao_url", "homepage_url"]:
                val = info_data.get(field)
                status = "✅ found" if val else "❌ empty"
                test_result["information"]["parsed_result"][field] = status
                print(f"    {status.replace('found', '')} {field}: {str(val)[:60] if val else ''}")

            await asyncio.sleep(2)

            # ── 4. /photo ──
            print(f"\n  📷 Test 4: /photo")
            photo_url = f"https://m.place.naver.com/hospital/{place_id}/photo?filterType=%EC%97%85%EC%B2%B4"
            resp = await client.get(photo_url, referer=home_url)
            html = resp.text

            (Path(RAW_HTML_DIR) / f"photo_{place_id}.html").write_text(html, encoding="utf-8")

            photo_data = NaverDataParser.parse_photos(html)

            test_result["photos"] = {
                "http_status": resp.status_code,
                "photo_count_initial": photo_data["total_count"],
                "has_more": photo_data["has_more"],
                "html_size": len(html),
                "sample_urls": photo_data["photos"][:3],
            }

            if photo_data["total_count"] > 0:
                photo_ok += 1
                print(f"    ✅ 사진: {photo_data['total_count']}장 (has_more={photo_data['has_more']})")
            else:
                print(f"    ❌ 사진 없음")

            report["tests"].append(test_result)

            if idx < len(hospitals) - 1:
                print(f"  ⏳ 3초 대기...")
                await asyncio.sleep(3)

    finally:
        await client.close()

    # ── 최종 판단 ──
    total = len(hospitals)
    report["summary"] = {
        "total_tests": total,
        "search_id_success": search_ok,
        "home_apollo_state": home_ok,
        "info_apollo_state": info_ok,
        "photo_success": photo_ok,
    }

    if search_ok == total and home_ok == total:
        report["decision"] = "HTTP_ONLY"
        report["decision_detail"] = "✅ 모든 페이지에서 __APOLLO_STATE__ 확인. HTTP-Only 전략 확정."
    elif search_ok == total:
        report["decision"] = "HTTP_MOSTLY"
        report["decision_detail"] = "⚠️ 검색 OK, 일부 페이지 APOLLO 없음. DOM 폴백으로 진행 가능."
    elif search_ok > 0:
        report["decision"] = "HYBRID"
        report["decision_detail"] = "⚠️ 일부만 HTTP 가능. headed 브라우저 부분 도입 필요."
    else:
        report["decision"] = "NEEDS_BROWSER"
        report["decision_detail"] = "❌ HTTP-Only 불가. headed(GUI) 브라우저 전환 필요."

    # 리포트 저장
    report_path = Path(RESULTS_DIR) / "phase1_report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n📄 리포트 저장: {report_path}")

    print(f"\n{'=' * 60}")
    print(f"  Phase 1 검증 결과")
    print(f"{'=' * 60}")
    print(f"  테스트 병원: {total}개")
    print(f"  검색 ID 성공: {search_ok}/{total}")
    print(f"  /home APOLLO: {home_ok}/{total}")
    print(f"  /info APOLLO: {info_ok}/{total}")
    print(f"  /photo 성공: {photo_ok}/{total}")
    print(f"\n  🎯 판단: {report['decision']}")
    print(f"  {report['decision_detail']}")
    print(f"{'=' * 60}")

    return report


if __name__ == "__main__":
    custom = None
    if len(sys.argv) > 1 and sys.argv[1] == "--name" and len(sys.argv) > 2:
        custom = sys.argv[2]
    asyncio.run(run_probe(custom))
