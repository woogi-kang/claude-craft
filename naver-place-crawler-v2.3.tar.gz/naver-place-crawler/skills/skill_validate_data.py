"""
skills/skill_validate_data.py — Skill 5: 데이터 검증 (3단계)
Level 1: 필수 (place_id, 진료시간)
Level 2: 형식 (URL, 사진)
Level 3: 교차 (CSV 원본과 비교)
"""
from __future__ import annotations
import json
from pathlib import Path
from typing import Optional
from core.logger import logger


def validate_hospital(record: dict, csv_row: Optional[dict] = None) -> dict:
    issues = []

    # Level 1
    if not record.get("place_id"):
        issues.append({"level": 1, "field": "place_id", "message": "Place ID 없음"})
    if record.get("crawl_status") == "success" and not record.get("operating_hours_json"):
        issues.append({"level": 1, "field": "operating_hours", "message": "성공인데 진료시간 없음"})

    # Level 2
    for f in ["youtube_url", "instagram_url", "blog_url", "booking_url", "kakao_url"]:
        val = record.get(f)
        if val and not val.startswith("http"):
            issues.append({"level": 2, "field": f, "message": f"URL 형식 오류: {val[:50]}"})
    if record.get("booking_url") and "booking.naver.com" not in record["booking_url"]:
        issues.append({"level": 2, "field": "booking_url", "message": "booking.naver.com 아님"})
    pc = record.get("photo_count", 0)
    pd = record.get("photo_dir", "")
    if pc > 0 and pd:
        p = Path(pd)
        if p.exists():
            actual = len(list(p.glob("*.jpg")))
            if actual < pc * 0.8:
                issues.append({"level": 2, "field": "photos",
                               "message": f"사진 수 불일치: DB={pc} 실제={actual}"})

    # Level 3
    if csv_row:
        dist = record.get("match_distance_m", 0)
        if dist and float(dist) > 300:
            issues.append({"level": 3, "field": "distance",
                           "message": f"매칭 거리 {dist}m"})

    if any(i["level"] == 1 for i in issues): status = "error"
    elif any(i["level"] == 3 for i in issues): status = "mismatch"
    elif issues: status = "warning"
    else: status = "valid"
    return {"status": status, "issues": issues}


def validate_all(records: list[dict], csv_rows: Optional[list[dict]] = None) -> dict:
    csv_map = {str(r.get("NO", "")): r for r in (csv_rows or [])}
    summary = {"total": len(records), "valid": 0, "warning": 0, "error": 0, "mismatch": 0}
    details = []
    for rec in records:
        csv_row = csv_map.get(str(rec.get("csv_no", "")))
        res = validate_hospital(rec, csv_row)
        summary[res["status"]] += 1
        details.append({"csv_no": rec.get("csv_no"), "naver_name": rec.get("naver_name"),
                         "status": res["status"], "issues": res["issues"]})
    logger.info(f"검증: {summary['total']}건 → valid={summary['valid']} warn={summary['warning']} "
                f"err={summary['error']} mismatch={summary['mismatch']}")
    return {"summary": summary, "details": details}


if __name__ == "__main__":
    from core.config import DB_PATH
    from core.checkpoint_db import CheckpointDB
    db = CheckpointDB(DB_PATH)
    res = validate_all(db.get_all_results())
    print(json.dumps(res["summary"], indent=2))
    db.close()
