"""Skill 1: 네이버 검색 → Place ID 획득 (3-Tier 매칭 v2.2)

Tier 1: 이름 검색 → 후보 1개 + 고유이름 → 즉시 채택
Tier 2: 이름+지역 검색 → 후보 축소
Tier 3: 후보별 /home 방문 → APOLLO 좌표 → CSV 좌표 매칭 (핵심)

Tier 3이 동명 병원 문제를 해결하는 핵심 로직.
최대 5개 후보까지 /home을 방문하여 좌표를 가져와 비교합니다.
"""
import re
from collections import Counter

from core.logger import logger
from core.config import NAVER_SEARCH_URL
from core.http_client import NaverHTTPClient
from core.naver_data_parser import NaverDataParser
from core.rate_limiter import RateLimiter
from core.coordinate_matcher import (
    match_by_coordinates, match_best_candidate,
    name_similarity, extract_region, naver_coord_to_latlng,
    haversine_distance, build_search_queries,
)


# Tier 3에서 최대 방문할 후보 수
MAX_TIER3_VISITS = 5


class SearchResult:
    """Place ID 검색 결과"""
    def __init__(self):
        self.place_id: str = ""
        self.success: bool = False
        self.match_tier: int = 0
        self.match_confidence: float = 0.0
        self.match_distance_m: float = 0.0
        self.match_method: str = ""
        self.candidates_count: int = 0
        self.home_data: dict = {}  # Tier 3에서 가져온 home 데이터 (재활용)


def get_duplicate_names(csv_rows: list) -> set:
    """CSV에서 중복 이름 set 반환"""
    counts = Counter(r.get("naver_name", "") for r in csv_rows)
    return {name for name, cnt in counts.items() if cnt > 1}


async def search_place_id(
    client: NaverHTTPClient,
    limiter: RateLimiter,
    csv_row: dict,
    is_duplicate_name: bool = False,
) -> SearchResult:
    """3-Tier 전략으로 Place ID 검색

    Args:
        client: HTTP 클라이언트
        limiter: 속도 제어기
        csv_row: CSV 행 (naver_name, naver_address, naver_mapx, naver_mapy)
        is_duplicate_name: 동명 병원 여부

    Returns:
        SearchResult
    """
    name = csv_row.get("naver_name", "")
    address = csv_row.get("naver_address", "")
    mapx = float(csv_row.get("naver_mapx", 0) or 0)
    mapy = float(csv_row.get("naver_mapy", 0) or 0)
    has_coords = mapx > 0 and mapy > 0

    result = SearchResult()

    # ── Tier 1: 이름만 검색 ──────────────────
    candidates = await _search_naver(client, f"{name} 병원")
    result.candidates_count = len(candidates)

    if not candidates:
        logger.debug(f"Tier 1 결과 없음: {name}")
    elif len(candidates) == 1 and not is_duplicate_name:
        # 단일 결과 + 고유 이름 → 바로 채택
        result.place_id = candidates[0]["place_id"]
        result.match_tier = 1
        result.match_confidence = 0.9
        result.match_method = "single_result"
        result.success = True
        logger.debug(f"Tier 1 성공 (단일+고유): {name} → {result.place_id}")
        return result

    # ── Tier 2: 이름 + 지역 검색 ──────────────
    if address:
        _, gugun = extract_region(address)
        if gugun:
            await limiter.page_delay()
            candidates2 = await _search_naver(client, f"{name} {gugun} 병원")
            if candidates2:
                candidates = candidates2  # 더 좁혀진 결과로 교체
                result.candidates_count = len(candidates)

            # 단일 결과 + 이름 유사도 높음 → 채택
            if len(candidates) == 1:
                c = candidates[0]
                c_name = c.get("name", "")
                sim = name_similarity(name, c_name) if c_name else 0.7
                if sim >= 0.5:
                    result.place_id = c["place_id"]
                    result.match_tier = 2
                    result.match_confidence = sim * 0.9
                    result.match_method = "tier2_single"
                    result.success = True
                    logger.debug(f"Tier 2 성공 (단일): {name} ({gugun}) → {result.place_id}")
                    return result

    # ── Tier 3: 후보별 /home 방문 → APOLLO 좌표 매칭 ──
    if has_coords and candidates:
        target_lat, target_lng = naver_coord_to_latlng(mapx, mapy)

        # 최대 MAX_TIER3_VISITS개 후보 방문
        visit_candidates = candidates[:MAX_TIER3_VISITS]
        enriched = []

        for i, c in enumerate(visit_candidates):
            pid = c["place_id"]
            await limiter.page_delay()

            try:
                home_url = f"https://m.place.naver.com/hospital/{pid}/home"
                resp = await client.get(home_url)
                home_data = NaverDataParser.parse_home(resp.text, pid)

                apollo_lat = home_data.get("coordinate_y")
                apollo_lng = home_data.get("coordinate_x")

                if apollo_lat and apollo_lng:
                    dist = haversine_distance(
                        target_lat, target_lng,
                        float(apollo_lat), float(apollo_lng),
                    )
                    enriched.append({
                        "place_id": pid,
                        "lat": float(apollo_lat),
                        "lng": float(apollo_lng),
                        "name": home_data.get("name", ""),
                        "address": home_data.get("road_address", ""),
                        "distance_m": round(dist, 1),
                        "_home_data": home_data,  # 재활용
                    })
                    logger.debug(
                        f"  Tier 3 후보 [{i+1}/{len(visit_candidates)}] "
                        f"{pid}: {home_data.get('name', '?')} → {dist:.0f}m"
                    )

                    # 거리 10m 이내면 즉시 확정 (동일 좌표원)
                    if dist <= 10:
                        result.place_id = pid
                        result.match_tier = 3
                        result.match_confidence = 1.0
                        result.match_distance_m = round(dist, 1)
                        result.match_method = "tier3_exact_coord"
                        result.home_data = home_data
                        result.success = True
                        logger.debug(f"Tier 3 즉시 확정: {name} → {pid} ({dist:.1f}m)")
                        return result
                else:
                    logger.debug(f"  Tier 3 후보 [{i+1}] {pid}: 좌표 없음")
            except Exception as e:
                logger.warning(f"  Tier 3 후보 [{i+1}] {pid} 방문 실패: {e}")

        # 종합 점수 매칭
        if enriched:
            matched = match_best_candidate(csv_row, enriched)
            if matched:
                result.place_id = matched["place_id"]
                result.match_tier = 3
                result.match_confidence = matched.get("match_confidence", 0.5)
                result.match_distance_m = matched.get("match_distance_m", 0)
                result.match_method = "tier3_coord_match"
                result.home_data = matched.get("_home_data", {})
                result.success = True
                logger.debug(
                    f"Tier 3 성공: {name} → {result.place_id} "
                    f"(거리: {result.match_distance_m}m, 신뢰도: {result.match_confidence:.2f})"
                )
                return result

    # ── Tier 4 폴백: 이름 + 도로명 ──────────────
    if not result.success and address:
        road = re.search(r"(\S+[로길])\s", address)
        if road:
            await limiter.page_delay()
            candidates3 = await _search_naver(client, f"{name} {road.group(1)}")
            if candidates3 and has_coords:
                # 다시 Tier 3 방식으로 좌표 확인
                pid = candidates3[0]["place_id"]
                try:
                    await limiter.page_delay()
                    home_url = f"https://m.place.naver.com/hospital/{pid}/home"
                    resp = await client.get(home_url)
                    home_data = NaverDataParser.parse_home(resp.text, pid)

                    apollo_lat = home_data.get("coordinate_y")
                    apollo_lng = home_data.get("coordinate_x")
                    if apollo_lat and apollo_lng:
                        dist = haversine_distance(
                            target_lat, target_lng,
                            float(apollo_lat), float(apollo_lng),
                        )
                        if dist <= 500:
                            result.place_id = pid
                            result.match_tier = 4
                            result.match_confidence = 0.6 if dist <= 100 else 0.4
                            result.match_distance_m = round(dist, 1)
                            result.match_method = "tier4_road_fallback"
                            result.home_data = home_data
                            result.success = True
                            return result
                except Exception as e:
                    logger.warning(f"Tier 4 실패: {e}")

    if not result.success:
        result.match_method = "failed"
        logger.warning(f"매칭 실패: {name} ({address[:30]})")

    return result


async def _search_naver(client: NaverHTTPClient, query: str) -> list:
    """네이버 검색 → 플레이스 후보 리스트"""
    try:
        response = await client.get(
            NAVER_SEARCH_URL,
            params={"query": query, "sm": "mtp_hty.top", "where": "m"},
        )
        if response.status_code != 200:
            logger.warning(f"검색 HTTP {response.status_code}: {query}")
            return []
        return NaverDataParser.parse_search_results(response.text)
    except Exception as e:
        logger.error(f"검색 오류 '{query}': {e}")
        return []
