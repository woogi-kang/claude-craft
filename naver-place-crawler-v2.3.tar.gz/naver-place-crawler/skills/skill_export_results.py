"""Skill 6: 결과 저장 및 리포트 생성"""
import csv
import json
from datetime import datetime
from pathlib import Path
from core.logger import logger
from core.checkpoint_db import CheckpointDB


def export_all(db: CheckpointDB, output_dir: Path):
    """전체 결과를 CSV + JSON + 리포트로 내보내기"""
    output_dir.mkdir(parents=True, exist_ok=True)
    all_rows = db.get_all_results()

    # 1) CSV 내보내기
    csv_path = output_dir / "hospital_data.csv"
    _export_csv(all_rows, csv_path)

    # 2) JSON 내보내기
    json_path = output_dir / "hospital_data.json"
    _export_json(all_rows, json_path)

    # 3) 실패 목록
    failed = [r for r in all_rows if r["crawl_status"] == "failed"]
    if failed:
        failed_path = output_dir / "failed_hospitals.csv"
        _export_csv(failed, failed_path)
        logger.info(f"실패 목록: {failed_path} ({len(failed)}건)")

    # 4) 리포트
    report_path = output_dir / "crawling_report.md"
    _generate_report(db, all_rows, report_path)

    logger.info(f"내보내기 완료: {output_dir}")


def _export_csv(rows: list, path: Path):
    if not rows:
        return
    fieldnames = list(rows[0].keys())
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    logger.info(f"CSV 저장: {path} ({len(rows)}행)")


def _export_json(rows: list, path: Path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2, default=str)
    logger.info(f"JSON 저장: {path} ({len(rows)}행)")


def _generate_report(db: CheckpointDB, all_rows: list, path: Path):
    stats = db.get_status_summary()
    total = stats.get("total", 0)
    success = stats.get("success", 0)

    # 매칭 티어 분포
    tier_counts = {}
    for r in all_rows:
        t = r.get("match_tier") or "N/A"
        tier_counts[t] = tier_counts.get(t, 0) + 1

    report = f"""# 크롤링 리포트
생성일: {datetime.now().strftime('%Y-%m-%d %H:%M')}

## 요약
| 항목 | 건수 | 비율 |
|------|------|------|
| 전체 | {total} | 100% |
| 성공 | {success} | {success/max(total,1)*100:.1f}% |
| 부분 성공 | {stats.get('partial',0)} | {stats.get('partial',0)/max(total,1)*100:.1f}% |
| 실패 | {stats.get('failed',0)} | {stats.get('failed',0)/max(total,1)*100:.1f}% |
| 미처리 | {stats.get('pending',0)} | {stats.get('pending',0)/max(total,1)*100:.1f}% |

## 매칭 티어 분포
| Tier | 건수 | 비율 |
|------|------|------|
"""
    for tier, cnt in sorted(tier_counts.items(), key=str):
        report += f"| {tier} | {cnt} | {cnt/max(total,1)*100:.1f}% |\n"

    report += f"\n## 사진\n- 총 사진 수: {stats.get('photo_count', 0):,}장\n"

    path.write_text(report, encoding="utf-8")
    logger.info(f"리포트 저장: {path}")
