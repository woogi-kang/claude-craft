"""Skill 2: /home 페이지 크롤링 (v2.2)

APOLLO_STATE에서 기본 정보 + DOM에서 영업시간/휴무일 추출.
"""

import asyncio
from core.http_client import NaverHTTPClient
from core.naver_data_parser import NaverDataParser
from core.rate_limiter import page_delay
from core.logger import get_logger

logger = get_logger("skill_home")


async def crawl_home(
    client: NaverHTTPClient,
    place_id: str,
    referer: str = None,
) -> dict:
    """home 페이지 크롤링 → 영업시간/편의시설/기본정보

    Returns:
        {
            "operating_hours": dict|None,
            "lunch_break": str|None,
            "closed_days": str|None,
            "amenities": list|None,
            "name": str|None,
            "road_address": str|None,
            "address": str|None,
            "category": str|None,
            "coordinate_x": float|None,
            "coordinate_y": float|None,
            "phone": str|None,
            "visitor_reviews_total": int|None,
            "visitor_reviews_score": float|None,
            "homepage_url": str|None,
            "blog_url": str|None,
        }
    """
    url = f"https://m.place.naver.com/hospital/{place_id}/home"
    response = await client.get(url, referer=referer)
    html = response.text

    result = NaverDataParser.parse_home(html, place_id)

    logger.info(
        f"[{place_id}] home 파싱 완료 | "
        f"이름={result.get('name')} | "
        f"영업시간={'✅' if result.get('operating_hours') else '❌'} | "
        f"편의시설={result.get('amenities')}"
    )

    await page_delay()
    return result
