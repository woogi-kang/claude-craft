"""Skill 4: /photo 페이지 크롤링 + 비동기 다운로드 (v2.3)

APOLLO_STATE에서 업체등록 사진(ugcModeling) URL 추출 → 전체 다운로드.
사진 없으면 스킵.
"""

import asyncio
import json
from pathlib import Path

from core.http_client import NaverHTTPClient
from core.naver_data_parser import NaverDataParser
from core.config import PHOTO_DIR, PHOTO_CONCURRENT_LIMIT
from core.rate_limiter import page_delay
from core.logger import get_logger

logger = get_logger("skill_photo")


async def crawl_photos(
    client: NaverHTTPClient,
    place_id: str,
    referer: str = None,
    skip_download: bool = False,
) -> dict:
    """photo 페이지 크롤링 → 업체등록 사진 다운로드

    Returns:
        {
            "photo_count": int,     # 다운로드된 사진 수
            "total_on_page": int,   # 서버가 알려주는 전체 수
            "photo_dir": str|None,
            "photos": [{"url": str, "path": str, "size": int}],
            "has_more": bool,
            "source": str,          # "apollo" or "dom" or "none"
        }
    """
    url = f"https://m.place.naver.com/hospital/{place_id}/photo?filterType=%EC%97%85%EC%B2%B4"
    response = await client.get(url, referer=referer)
    html = response.text

    parsed = NaverDataParser.parse_photos(html, place_id)
    photo_urls = parsed["photos"]

    result = {
        "photo_count": parsed["photo_count"],
        "total_on_page": parsed["total_on_page"],
        "photo_dir": None,
        "photos": [],
        "has_more": parsed["has_more"],
        "source": parsed["source"],
    }

    if not photo_urls:
        logger.info(f"[{place_id}] 업체 사진 없음 — 스킵")
        return result

    if skip_download:
        logger.info(f"[{place_id}] 사진 {len(photo_urls)}장 (다운로드 스킵)")
        return result

    # 다운로드 디렉토리
    photo_dir = Path(PHOTO_DIR) / place_id
    photo_dir.mkdir(parents=True, exist_ok=True)
    result["photo_dir"] = str(photo_dir)

    # 비동기 병렬 다운로드
    sem = asyncio.Semaphore(PHOTO_CONCURRENT_LIMIT)

    async def download_one(idx: int, img_url: str):
        async with sem:
            try:
                resp = await client.get(
                    img_url,
                    referer=f"https://m.place.naver.com/hospital/{place_id}/photo",
                )
                if resp.status_code == 200 and len(resp.content) > 1024:
                    ct = resp.headers.get("content-type", "")
                    ext = ".jpg"
                    if "png" in ct: ext = ".png"
                    elif "gif" in ct: ext = ".gif"
                    elif "webp" in ct: ext = ".webp"

                    filename = f"{idx:03d}{ext}"
                    filepath = photo_dir / filename
                    filepath.write_bytes(resp.content)

                    return {
                        "url": img_url,
                        "path": str(filepath),
                        "size": len(resp.content),
                    }
            except Exception as e:
                logger.warning(f"[{place_id}] 사진 {idx} 다운로드 실패: {e}")
            return None

    tasks = [download_one(i, u) for i, u in enumerate(photo_urls)]
    results = await asyncio.gather(*tasks)

    for r in results:
        if r:
            result["photos"].append(r)

    result["photo_count"] = len(result["photos"])

    # 메타데이터 저장
    meta_path = photo_dir / "metadata.json"
    meta_path.write_text(json.dumps({
        "place_id": place_id,
        "total_on_page": parsed["total_on_page"],
        "has_more": parsed["has_more"],
        "downloaded": len(result["photos"]),
        "source": parsed["source"],
        "photos": result["photos"],
    }, ensure_ascii=False, indent=2), encoding="utf-8")

    logger.info(
        f"[{place_id}] 사진 다운로드 완료 | "
        f"{len(result['photos'])}/{len(photo_urls)}장 | "
        f"전체: {parsed['total_on_page']}장 | "
        f"소스: {parsed['source']}"
    )

    await page_delay()
    return result
