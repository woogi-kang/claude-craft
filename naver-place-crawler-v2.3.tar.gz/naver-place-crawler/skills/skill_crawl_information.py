"""Skill 3: /information 페이지 크롤링 (v2.2)

DOM 파싱으로 소개, 주차, SNS 링크 추출.
"""

import asyncio
from core.http_client import NaverHTTPClient
from core.naver_data_parser import NaverDataParser
from core.rate_limiter import page_delay
from core.logger import get_logger

logger = get_logger("skill_info")


async def crawl_information(
    client: NaverHTTPClient,
    place_id: str,
    referer: str = None,
) -> dict:
    """information 페이지 크롤링 → 소개/주차/SNS

    Returns:
        {
            "description": str|None,
            "parking_available": bool|None,
            "parking_detail": str|None,
            "youtube_url": str|None,
            "instagram_url": str|None,
            "blog_url": str|None,
            "booking_url": str|None,
            "kakao_url": str|None,
            "homepage_url": str|None,
            "other_links": list,
        }
    """
    url = f"https://m.place.naver.com/hospital/{place_id}/information"
    response = await client.get(url, referer=referer)
    html = response.text

    result = NaverDataParser.parse_information(html)

    logger.info(
        f"[{place_id}] information 파싱 완료 | "
        f"소개={'✅' if result.get('description') else '❌'} | "
        f"주차={'✅' if result.get('parking_detail') else '❌'} | "
        f"링크={sum(1 for k in ['youtube_url','instagram_url','blog_url','booking_url','kakao_url','homepage_url'] if result.get(k))}개"
    )

    await page_delay()
    return result
