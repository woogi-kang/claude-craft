#!/bin/bash
# 지역별 분할 크롤링 실행 스크립트
# 사용법: bash run_regions.sh [지역번호]
#
# 권장 실행 순서 (소규모 → 대규모):
#   Day 1: 제주 + 세종 + 강원 + 전남 (170건, ~1시간)
#   Day 2: 충북 + 충남 + 전북 + 울산 (310건, ~2시간)
#   Day 3: 경북 + 경남 + 광주 + 대전 (443건, ~3시간)
#   Day 4: 대구 + 인천 + 부산 (644건, ~4시간)
#   Day 5: 경기도 (965건, ~6.5시간)
#   Day 6: 서울 강남/서초/송파/강동/강서/양천/영등포 (~600건, ~4시간)
#   Day 7: 서울 나머지 (~1100건, ~7시간)

set -e

case "${1:-help}" in
  1|day1)
    echo "=== Day 1: 제주 + 세종 + 강원 + 전남 ==="
    python3 agent_orchestrator.py --region 제주특별자치도
    python3 agent_orchestrator.py --region 세종특별자치시
    python3 agent_orchestrator.py --region 강원특별자치도
    python3 agent_orchestrator.py --region 전라남도
    ;;
  2|day2)
    echo "=== Day 2: 충북 + 충남 + 전북 + 울산 ==="
    python3 agent_orchestrator.py --region 충청북도
    python3 agent_orchestrator.py --region 충청남도
    python3 agent_orchestrator.py --region 전북특별자치도
    python3 agent_orchestrator.py --region 울산광역시
    ;;
  3|day3)
    echo "=== Day 3: 경북 + 경남 + 광주 + 대전 ==="
    python3 agent_orchestrator.py --region 경상북도
    python3 agent_orchestrator.py --region 경상남도
    python3 agent_orchestrator.py --region 광주광역시
    python3 agent_orchestrator.py --region 대전광역시
    ;;
  4|day4)
    echo "=== Day 4: 대구 + 인천 + 부산 ==="
    python3 agent_orchestrator.py --region 대구광역시
    python3 agent_orchestrator.py --region 인천광역시
    python3 agent_orchestrator.py --region 부산광역시
    ;;
  5|day5)
    echo "=== Day 5: 경기도 ==="
    python3 agent_orchestrator.py --region 경기도
    ;;
  6|day6)
    echo "=== Day 6: 서울 강남권 ==="
    python3 agent_orchestrator.py --region 서울특별시 --subregion 강남구,서초구,송파구,강동구,강서구,양천구,영등포구
    ;;
  7|day7)
    echo "=== Day 7: 서울 나머지 ==="
    python3 agent_orchestrator.py --region 서울특별시 --subregion 관악구,동작구,구로구,금천구,마포구,서대문구,용산구,중구,종로구
    python3 agent_orchestrator.py --region 서울특별시 --subregion 성북구,동대문구,중랑구,광진구,성동구,노원구,도봉구,강북구,은평구
    ;;
  status)
    python3 agent_orchestrator.py --status
    ;;
  retry)
    python3 agent_orchestrator.py --retry-failed
    ;;
  help|*)
    echo "사용법: bash run_regions.sh [옵션]"
    echo ""
    echo "  1 (day1)   제주+세종+강원+전남      170건  ~1시간"
    echo "  2 (day2)   충북+충남+전북+울산        310건  ~2시간"
    echo "  3 (day3)   경북+경남+광주+대전        443건  ~3시간"
    echo "  4 (day4)   대구+인천+부산             644건  ~4시간"
    echo "  5 (day5)   경기도                    965건  ~6.5시간"
    echo "  6 (day6)   서울 강남권                ~600건  ~4시간"
    echo "  7 (day7)   서울 나머지                ~1100건  ~7시간"
    echo "  status     진행 상태 확인"
    echo "  retry      실패건 재시도"
    echo ""
    echo "  합계: 4,255건, 7일 완료 (하루 1~7시간)"
    ;;
esac

echo ""
echo "=== 완료. 상태 확인: bash run_regions.sh status ==="
