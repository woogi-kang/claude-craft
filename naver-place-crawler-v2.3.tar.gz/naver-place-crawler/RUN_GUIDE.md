# 네이버 플레이스 크롤러 v2.2 — 실행 가이드

## 사전 준비

```bash
# 패키지 설치
pip install httpx pydantic

# 압축 해제 후 디렉토리 이동
cd naver-place-crawler
```

## 1단계: Phase 1 확장 테스트 (필수 — 10개 병원)

```bash
python3 phase1_extended.py
```

**검증 항목:**
- Tier 3 좌표 매칭: 동명 병원(아름다운피부과 서초/부산)이 각각 올바른 ID로 매칭되는지
- 파서 안정성: APOLLO_STATE + DOM 파싱
- 전체 파이프라인: 검색 → Home → Info → Photo

**결과:** `results/phase1_extended_report.json`

## 2단계: 지역별 크롤링 (본 실행)

### 방법 A: 스크립트 사용 (권장)
```bash
# Day 1: 소규모 지역 (170건, ~1시간)
bash run_regions.sh 1

# Day 2: 중소 지역 (310건, ~2시간)
bash run_regions.sh 2

# ... Day 7까지
```

### 방법 B: 직접 지역 지정
```bash
# 단일 지역
python3 agent_orchestrator.py --region 제주특별자치도

# 서울 구 단위 분할
python3 agent_orchestrator.py --region 서울특별시 --subregion 강남구,서초구

# 테스트 (5건만)
python3 agent_orchestrator.py --region 제주특별자치도 --limit 5
```

### 상태 확인
```bash
# 진행 상태
python3 agent_orchestrator.py --status

# 또는
bash run_regions.sh status
```

### 실패건 재시도
```bash
python3 agent_orchestrator.py --retry-failed
# 또는
bash run_regions.sh retry
```

## 지역별 크롤링 스케줄

| Day | 지역 | 건수 | 예상 시간 | 명령 |
|-----|------|------|----------|------|
| 1 | 제주+세종+강원+전남 | 170 | ~1시간 | `bash run_regions.sh 1` |
| 2 | 충북+충남+전북+울산 | 310 | ~2시간 | `bash run_regions.sh 2` |
| 3 | 경북+경남+광주+대전 | 443 | ~3시간 | `bash run_regions.sh 3` |
| 4 | 대구+인천+부산 | 644 | ~4시간 | `bash run_regions.sh 4` |
| 5 | 경기도 | 965 | ~6.5시간 | `bash run_regions.sh 5` |
| 6 | 서울 강남권 | ~600 | ~4시간 | `bash run_regions.sh 6` |
| 7 | 서울 나머지 | ~1100 | ~7시간 | `bash run_regions.sh 7` |

**합계: 4,255건, 7일 (~28시간)**

## 속도 설정 (config.py)

| 항목 | 값 | 설명 |
|------|-----|------|
| REQUEST_DELAY | 2.5~5.5초 | 같은 병원 내 페이지 이동 |
| PAGE_READ_DELAY | 3~7초 | 병원 간 전환 |
| BATCH_SIZE | 40건 | 배치 크기 |
| BATCH_COOLDOWN | 90~180초 | 배치 후 휴식 |
| REGION_COOLDOWN | 300초 | 지역 전환 시 5분 |
| 10% jitter | +2~8초 | 랜덤 추가 대기 |

더 안전하게 하려면 `REQUEST_DELAY_MIN`과 `PAGE_READ_DELAY_MIN`을 높이세요.

## 결과물

```
results/
├── db/crawl.db           ← SQLite 체크포인트 (중단 후 이어서 가능)
├── hospital_data.csv     ← 전체 결과 CSV
├── hospital_data.json    ← 전체 결과 JSON
├── failed_hospitals.csv  ← 실패 목록
├── crawling_report.md    ← 통계 리포트
└── photos/{place_id}/    ← 사진 (최대 5장/병원)
```

## 차단 대응

1. **연속 차단 5회** → 자동 중단 (30분 후 `--retry-failed`)
2. **403/429 응답** → 자동 대기 (60초 → 180초 → 600초 → 1800초)
3. **세션 로테이션** → 200요청마다 자동 교체

## 문제 해결

```bash
# DB 상태 직접 확인
sqlite3 results/db/crawl.db "SELECT crawl_status, COUNT(*) FROM hospitals GROUP BY crawl_status"

# 특정 병원 확인
sqlite3 results/db/crawl.db "SELECT * FROM hospitals WHERE naver_name='아름다운피부과의원'"

# 실패 사유 확인
sqlite3 results/db/crawl.db "SELECT naver_name, error_messages_json FROM hospitals WHERE crawl_status='failed' LIMIT 10"
```
