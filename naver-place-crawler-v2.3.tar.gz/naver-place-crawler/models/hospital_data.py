"""
models/hospital_data.py — Pydantic 데이터 모델
"""
from __future__ import annotations
from typing import Optional
from pydantic import BaseModel


class HospitalCrawlData(BaseModel):
    # 원본
    csv_no: int
    naver_name: str
    naver_address: str = ""

    # Skill 1
    place_id: Optional[str] = None
    match_tier: Optional[int] = None
    match_confidence: Optional[float] = None
    match_distance_m: Optional[float] = None
    match_method: Optional[str] = None

    # Skill 2
    operating_hours: Optional[dict | list | str] = None
    lunch_break: Optional[str] = None
    closed_days: Optional[list[str]] = None
    amenities: Optional[list[str]] = None

    # Skill 3
    description: Optional[str] = None
    parking_available: Optional[bool] = None
    parking_detail: Optional[str] = None
    youtube_url: Optional[str] = None
    instagram_url: Optional[str] = None
    blog_url: Optional[str] = None
    booking_url: Optional[str] = None
    kakao_url: Optional[str] = None
    other_links: Optional[list[str]] = None

    # Skill 4
    photo_count: int = 0
    photo_urls: Optional[list[str]] = None
    photo_dir: Optional[str] = None

    # Meta
    crawl_status: str = "pending"
    error_messages: Optional[list[str]] = None
