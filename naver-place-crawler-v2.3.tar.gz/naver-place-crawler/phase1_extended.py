"""Phase 1 확장 테스트: 10개 병원 — Tier 3 좌표 매칭 포함

Tier 3 핵심 검증:
  - 동명 병원(아름다운피부과 서초/부산, 오라클피부과 송파)이
    각각 올바른 Place ID로 매칭되는지 확인
  - 후보 /home 방문 → APOLLO 좌표 → CSV 좌표 비교

실행: python3 phase1_extended.py
결과: results/phase1_extended_report.json
"""

import asyncio
import json
import csv
import sys
import time
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

from core.http_client import NaverHTTPClient, BlockDetectedError
from core.naver_data_parser import NaverDataParser
from core.rate_limiter import RateLimiter
from core.coordinate_matcher import haversine_distance, naver_coord_to_latlng
from skills.skill_search_place_id import search_place_id, SearchResult
from skills.skill_crawl_home import crawl_home
from skills.skill_crawl_information import crawl_information
from skills.skill_crawl_photos import crawl_photos
from core.logger import logger

# 동명 포함 = True
TEST_HOSPITALS = [
    ("아름다운피부과의원", "서초구",   True),
    ("아름다운피부과의원", "연제구",   True),
    ("오라클피부과의원",   "송파구",   True),
    ("이룸의원",         "춘천시",   True),
    ("엠제이(MJ)올피부과의원", "중구", False),
    ("BJ라임의원",       "관악구",   False),
    ("꿀의원",           "제주시",   False),
    ("라메종의원",       "세종특별자치시", True),
    ("S아이니의원",      "구로구",   False),
    ("퓨어린의원 춘천점", "춘천시",   False),
]


def find_csv_row(name: str, addr_keyword: str) -> dict:
    csv_path = ROOT / "input" / "skin_clinics.csv"
    with open(csv_path, encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            if row["naver_name"] == name and addr_keyword in row["naver_address"]:
                return row
    return None


async def test_full_pipeline(client, limiter, csv_row, is_dup, idx):
    """단일 병원: 검색(Tier 1~3) + Home + Info + Photo"""
    name = csv_row["naver_name"]
    mapx = float(csv_row["naver_mapx"])
    mapy = float(csv_row["naver_mapy"])
    target_lat, target_lng = naver_coord_to_latlng(mapx, mapy)

    result = {
        "idx": idx,
        "name": name,
        "address": csv_row["naver_address"][:50],
        "csv_lat": round(target_lat, 7),
        "csv_lng": round(target_lng, 7),
        "is_duplicate": is_dup,
    }

    try:
        # ── Skill 1: Place ID (Tier 3 포함) ──
        sr = await search_place_id(client, limiter, csv_row, is_duplicate_name=is_dup)

        result["search"] = {
            "success": sr.success,
            "place_id": sr.place_id,
            "tier": sr.match_tier,
            "confidence": round(sr.match_confidence, 3),
            "distance_m": sr.match_distance_m,
            "method": sr.match_method,
            "candidates": sr.candidates_count,
            "has_cached_home": bool(sr.home_data),
        }

        if not sr.success:
            result["success"] = False
            result["error"] = f"매칭 실패: {sr.match_method}"
            return result

        place_id = sr.place_id

        # ── Skill 2: Home (Tier 3 캐시 재활용) ──
        home_data = sr.home_data
        if not home_data:
            await limiter.page_delay()
            home_data = await crawl_home(client, place_id)

        result["home"] = {
            "has_apollo": bool(home_data),
            "fields": {},
        }
        for field in ["name", "road_address", "category", "phone",
                       "coordinate_x", "coordinate_y",
                       "operating_hours", "lunch_break", "closed_days",
                       "amenities", "homepage_url", "blog_url",
                       "visitor_reviews_total", "visitor_reviews_score"]:
            val = home_data.get(field)
            result["home"]["fields"][field] = "✅" if val is not None else "❌"

        # 좌표 검증
        apollo_lat = home_data.get("coordinate_y")
        apollo_lng = home_data.get("coordinate_x")
        if apollo_lat and apollo_lng:
            dist = haversine_distance(target_lat, target_lng,
                                       float(apollo_lat), float(apollo_lng))
            result["coord_verify"] = {
                "distance_m": round(dist, 1),
                "matched": dist < 500,
            }

        # ── Skill 3: Information ──
        await limiter.page_delay()
        info_data = await crawl_information(client, place_id)
        result["information"] = {"fields": {}}
        for field in ["description", "parking_available", "parking_detail",
                       "homepage_url", "blog_url", "instagram_url"]:
            result["information"]["fields"][field] = "✅" if info_data.get(field) else "❌"

        # ── Skill 4: Photos ──
        await limiter.page_delay()
        photo_data = await crawl_photos(client, place_id, skip_download=True)
        result["photos"] = {
            "count": photo_data.get("photo_count", 0),
            "has_more": photo_data.get("has_more", False),
        }

        result["success"] = True

    except BlockDetectedError as e:
        result["error"] = f"차단: {e}"
        result["success"] = False
    except Exception as e:
        result["error"] = f"{type(e).__name__}: {e}"
        result["success"] = False

    return result


async def run():
    print("=" * 65)
    print("  Phase 1 확장 테스트: Tier 3 좌표 매칭 검증")
    print("=" * 65)

    test_rows = []
    for name, keyword, is_dup in TEST_HOSPITALS:
        row = find_csv_row(name, keyword)
        if row:
            test_rows.append((row, is_dup))
            print(f"  ✓ {name} ({keyword}) {'[동명]' if is_dup else ''}")
        else:
            print(f"  ✗ {name} ({keyword}) — CSV에서 못 찾음")

    client = NaverHTTPClient()
    limiter = RateLimiter()
    await client.start()

    results = []
    for i, (row, is_dup) in enumerate(test_rows):
        print(f"\n{'─' * 65}")
        print(f"  [{i+1}/{len(test_rows)}] {row['naver_name']} — {row['naver_address'][:40]}")
        print(f"{'─' * 65}")

        r = await test_full_pipeline(client, limiter, row, is_dup, i + 1)
        results.append(r)

        # 요약
        s = r.get("search", {})
        if r.get("success"):
            cv = r.get("coord_verify", {})
            dist = cv.get("distance_m", "?")
            match_ok = "✅" if cv.get("matched") else "⚠️"
            home_ok = sum(1 for v in r["home"]["fields"].values() if v == "✅")
            info_ok = sum(1 for v in r["information"]["fields"].values() if v == "✅")
            print(f"  ID: {s.get('place_id')} | Tier {s.get('tier')} ({s.get('method')})")
            print(f"  좌표: {match_ok} {dist}m | Home: {home_ok}/14 | Info: {info_ok}/6 | Photo: {r['photos']['count']}장")
        else:
            print(f"  ❌ {r.get('error', 'unknown')}")

        # 병원 간 딜레이
        await limiter.wait_page_navigation()

    await client.close()

    # ── 종합 ──
    print(f"\n{'=' * 65}")
    print("  종합 결과")
    print(f"{'=' * 65}")

    success = sum(1 for r in results if r.get("success"))
    coord_ok = sum(1 for r in results if r.get("coord_verify", {}).get("matched"))
    dup_tested = [r for r in results if r.get("is_duplicate")]
    dup_ok = sum(1 for r in dup_tested if r.get("coord_verify", {}).get("matched"))

    print(f"  전체: {len(results)}건")
    print(f"  크롤링 성공: {success}/{len(results)}")
    print(f"  좌표 매칭(<500m): {coord_ok}/{len(results)}")
    print(f"  동명 병원 매칭: {dup_ok}/{len(dup_tested)} ← 핵심 지표")

    # 이전 테스트와 비교
    tier3_used = sum(1 for r in results
                     if r.get("search", {}).get("tier", 0) == 3)
    print(f"  Tier 3 사용: {tier3_used}건")

    # JSON 저장
    report_path = ROOT / "results" / "phase1_extended_report.json"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump({
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "total": len(results),
            "success": success,
            "coord_matched": coord_ok,
            "duplicate_matched": f"{dup_ok}/{len(dup_tested)}",
            "tier3_used": tier3_used,
            "tests": results,
        }, f, ensure_ascii=False, indent=2)

    print(f"\n  📄 리포트: {report_path}")


if __name__ == "__main__":
    asyncio.run(run())
