# Phase 1 실행 가이드 (v2.2)

## 1. 환경 준비

```bash
cd naver-place-crawler

# Python 3.10+ 필요
python3 --version

# 의존성 설치
pip install httpx beautifulsoup4 loguru aiosqlite pydantic
```

## 2. Phase 1 검증 실행

```bash
# 기본 3개 병원 테스트
python3 phase1_probe.py

# 특정 병원 단건 테스트
python3 phase1_probe.py --name "강남세란의원"
```

### 실행 시 일어나는 일
1. **검색** → m.search.naver.com에서 Place ID 추출
2. **/home** → `__APOLLO_STATE__` + DOM에서 기본정보/영업시간
3. **/information** → DOM에서 소개/주차/SNS
4. **/photo** → DOM에서 사진 URL 5장

### 예상 소요시간
- 3개 병원: ~30초 (요청간 2~5초 딜레이)

## 3. 결과 확인

```bash
# Phase 1 리포트
cat results/phase1_report.json | python3 -m json.tool

# HTML 덤프 (디버깅용)
ls results/html_dump/
```

## 4. 오프라인 파서 테스트

```bash
# Phase 1 실행 후 저장된 HTML로 파서만 재검증
python3 tests/test_parser_offline.py

# 또는 HTML 디렉토리 직접 지정
python3 tests/test_parser_offline.py --html-dir results/html_dump
```

## 5. 예상 결과

```
🎯 판단: HTTP_ONLY
✅ 모든 페이지에서 __APOLLO_STATE__ 확인. HTTP-Only 전략 확정.
```

## 6. 문제 해결

| 증상 | 원인 | 해결 |
|------|------|------|
| `brotli` 관련 에러 | Accept-Encoding에 br 포함 | v2.2에서 이미 제거됨 ✅ |
| 모든 HTML에 한글 없음 | UTF-8 디코딩 실패 | Brotli 문제, 위와 동일 |
| Place ID 0개 | 검색 결과 CSR 로딩 | 검색 쿼리 조정 필요 |
| 403/429 응답 | 차단 감지 | 잠시 대기 후 재시도 |
| `__APOLLO_STATE__` 없음 | 네이버 구조 변경 | DOM 폴백으로 자동 전환 |

## 7. v2.2 변경사항 (이전 대비)

- `__PLACE_STATE__` → `__APOLLO_STATE__`로 핵심 데이터 소스 변경
- CSS selector 기반 DOM 파싱 (div.pSavy, div.eYvyf 등)
- Accept-Encoding에서 brotli(br) 제거
- 영업시간/점심시간/휴무일 정확 추출 구현
- 소개/주차/SNS 링크 DOM 셀렉터 확정
