# 네이버 플레이스 병원 크롤링 에이전트

네이버 플레이스에서 병원(피부과) 상세 데이터를 수집하는 HTTP-Only 크롤링 에이전트입니다.

## ⛔ 제약조건
- **Headless 브라우저 사용 금지** — httpx HTTP 요청만 사용
- 네이버 플레이스의 Next.js SSR 특성을 활용하여 `__NEXT_DATA__` JSON으로 데이터 추출

## 빠른 시작

```bash
# 1. 의존성 설치
pip install -r requirements.txt

# 2. CSV 파일 배치
cp skin_clinics.csv input/

# 3. Phase 1: HTTP-Only 전략 검증 (필수!)
python phase1_probe.py

# 4. 전체 크롤링 실행
python agent_orchestrator.py --input input/skin_clinics.csv

# 테스트용 (10건만)
python agent_orchestrator.py --input input/skin_clinics.csv --limit 10

# 특정 지역만
python agent_orchestrator.py --input input/skin_clinics.csv --region "서울특별시"

# 사진 스킵
python agent_orchestrator.py --input input/skin_clinics.csv --skip-photos
```

## 프로젝트 구조

```
naver-place-crawler/
├── phase1_probe.py              ⭐ Phase 1 검증 (먼저 실행!)
├── agent_orchestrator.py        메인 에이전트
├── core/                        공통 인프라
│   ├── config.py                중앙 설정
│   ├── http_client.py           HTTP 세션 관리
│   ├── naver_data_parser.py     __NEXT_DATA__ 파서
│   ├── coordinate_matcher.py    좌표 매칭
│   ├── checkpoint_db.py         SQLite 체크포인트
│   ├── rate_limiter.py          요청 속도 제어
│   ├── retry_handler.py         재시도 로직
│   ├── progress_monitor.py      진행률 모니터링
│   └── logger.py                로깅
├── skills/                      재사용 가능한 스킬
│   ├── skill_search_place_id.py   Skill 1: ID 검색
│   ├── skill_crawl_home.py        Skill 2: 진료시간
│   ├── skill_crawl_information.py Skill 3: 소개/링크
│   ├── skill_crawl_photos.py      Skill 4: 사진
│   ├── skill_validate_data.py     Skill 5: 검증
│   └── skill_export_results.py    Skill 6: 내보내기
├── models/
│   └── hospital_data.py         데이터 모델
├── input/                       입력 CSV
└── results/                     출력
    ├── hospital_data.csv
    ├── hospital_data.json
    ├── failed_hospitals.csv
    ├── crawling_report.md
    ├── photos/{place_id}/
    ├── db/checkpoint.db
    ├── html_dump/               원본 HTML (디버깅)
    └── logs/
```

## 수집 데이터

| 항목 | 출처 페이지 | Skill |
|------|------------|-------|
| Place ID | m.search.naver.com | Skill 1 |
| 진료시간 | /home | Skill 2 |
| 편의시설 | /home | Skill 2 |
| 소개 | /information | Skill 3 |
| 주차 여부 | /information | Skill 3 |
| YouTube 링크 | /information | Skill 3 |
| Instagram 링크 | /information | Skill 3 |
| 예약 링크 | /information | Skill 3 |
| 업체 사진 | /photo?filterType=업체 | Skill 4 |
