#!/bin/bash
# 서울 구 단위 크롤링 스크립트
#
# 사용법: bash run_seoul.sh [번호]
#
#   1) 강남구         571건  ~4시간
#   2) 서초구+마포구    317건  ~2시간
#   3) 송파구+중구+강서구 242건  ~1.5시간
#   4) 영등포구~성동구   189건  ~1.5시간
#   5) 양천구~은평구     191건  ~1.5시간
#   6) 서대문구~금천구    213건  ~1.5시간

set -e

case "${1:-help}" in
  1)
    echo "=== 서울 1/6: 강남구 (571건) ==="
    python3 agent_orchestrator.py --region 서울특별시 --subregion 강남구
    ;;
  2)
    echo "=== 서울 2/6: 서초구+마포구 (317건) ==="
    python3 agent_orchestrator.py --region 서울특별시 --subregion 서초구,마포구
    ;;
  3)
    echo "=== 서울 3/6: 송파구+중구+강서구 (242건) ==="
    python3 agent_orchestrator.py --region 서울특별시 --subregion 송파구,중구,강서구
    ;;
  4)
    echo "=== 서울 4/6: 영등포구+강동구+노원구+성동구 (197건) ==="
    python3 agent_orchestrator.py --region 서울특별시 --subregion 영등포구,강동구,노원구,성동구
    ;;
  5)
    echo "=== 서울 5/6: 양천구+관악구+광진구+동작구+용산구 (175건) ==="
    python3 agent_orchestrator.py --region 서울특별시 --subregion 양천구,관악구,광진구,동작구,용산구
    ;;
  6)
    echo "=== 서울 6/6: 나머지 (221건) ==="
    python3 agent_orchestrator.py --region 서울특별시 --subregion 은평구,서대문구,구로구,중랑구,성북구,동대문구,강북구,종로구,도봉구,금천구
    ;;
  all)
    echo "=== 서울 전체 순차 실행 ==="
    for i in 1 2 3 4 5 6; do
      bash run_seoul.sh $i
    done
    ;;
  status)
    python3 agent_orchestrator.py --status
    ;;
  retry)
    python3 agent_orchestrator.py --retry-failed
    ;;
  help|*)
    echo "서울 구 단위 크롤링"
    echo ""
    echo "  bash run_seoul.sh 1      강남구           571건  ~4시간"
    echo "  bash run_seoul.sh 2      서초구+마포구      317건  ~2시간"
    echo "  bash run_seoul.sh 3      송파구+중구+강서구   242건  ~1.5시간"
    echo "  bash run_seoul.sh 4      영등포+강동+노원+성동 197건  ~1.5시간"
    echo "  bash run_seoul.sh 5      양천+관악+광진+동작+용산 175건 ~1.5시간"
    echo "  bash run_seoul.sh 6      나머지 10개구       221건  ~1.5시간"
    echo "  bash run_seoul.sh all    전체 순차 실행"
    echo "  bash run_seoul.sh status 진행 상태"
    echo "  bash run_seoul.sh retry  실패건 재시도"
    echo ""
    echo "  합계: 1,723건 (~12시간)"
    ;;
esac
